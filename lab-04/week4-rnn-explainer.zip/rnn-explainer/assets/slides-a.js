/* Parts 0–2: the game, text → numbers, lookup tables */
(function () {
const { $, $$, esc, bars, mulberry32, pick, showChar } = U;

// ───────────────────────────── 1. Title
slide({
  part: 'Week 4', title: '',
  html: `
  <div style="padding-top:110px">
    <h3>CPSC 1710 · Week 4 · Language models, part 1</h3>
    <h1 style="font-size:100px;margin:10px 0 26px">Guess what comes next</h1>
    <p class="lede" style="max-width:1150px">From lookup tables to recurrent neural networks: how a machine learns to continue a sentence — with every assumption laid on the table.</p>
    <div style="margin-top:70px;display:flex;gap:34px;align-items:center;font-size:20px;color:var(--ink2)">
      <span class="tag">Colour key</span>
      <span><b class="x">blue</b> token / input</span>
      <span><b class="h">amber</b> memory</span>
      <span><b class="y">rose</b> probability / output</span>
      <span><b class="w">violet</b> weights</span>
      <span><b class="a">teal</b> assumption</span>
    </div>
  </div>`,
  says: [
    'Every language model you have heard of — ChatGPT, Claude, Gemini — plays one game: guess what comes next. Today we build that game from scratch, one assumption at a time.',
  ],
});

// ───────────────────────────── 2. The game
slide({
  part: 'Part 0 · The game', title: 'A language model guesses the next token',
  html: `
  <h1>A language model guesses the next token</h1>
  <p class="lede" style="font-size:40px!important;margin:26px 0 30px">The pink elephant tried to get into the car but it was too <span style="display:inline-block;width:120px;border-bottom:3px solid var(--y)"></span></p>
  <div class="row">
    <div class="col" data-step="1">
      ${bars([
        { lab: 'big', p: 0.58 }, { lab: 'large', p: 0.17 }, { lab: 'wide', p: 0.08 },
        { lab: 'heavy', p: 0.06 }, { lab: 'small', p: 0.03 }, { lab: '…others', p: 0.08, color: 'var(--muted)' },
      ])}
      <p class="small muted" style="margin-top:6px">Illustrative numbers. Every word in the vocabulary gets a probability; together they sum to 1.</p>
    </div>
    <div class="col stack">
      <div data-step="1" class="eq" style="font-size:36px;margin-top:10px">P( <span class="y">next token</span> <span class="op">|</span> <span class="x">all tokens so far</span> )</div>
      <p data-step="1" class="small center">read “|” as “given”</p>
      <div class="assume plural" data-step="2"><ul>
        <li>Text is a <b>sequence</b> of pieces (tokens).</li>
        <li>The model sees only what came <b>before</b>.</li>
        <li>The output is a <b>probability distribution</b>, not one answer.</li>
      </ul></div>
    </div>
  </div>`,
  says: [
    'Here is a sentence with its last word missing. You probably already have a strong guess.',
    'A language model makes the same guess — but instead of one answer, it gives a probability to every word it knows. These particular numbers are illustrative.',
    'Three assumptions are hiding in that picture. Text is a sequence. The model only sees what came before. And the output is a probability distribution: a list of non-negative numbers that add up to one.',
  ],
});

// ───────────────────────────── 3. Generation loop
const LOOP = [
  { ctx: 'The cat', c: [[' sat', 0.41], [' is', 0.22], [' was', 0.18], [' ran', 0.1]], pick: 0 },
  { ctx: 'The cat sat', c: [[' on', 0.52], [' down', 0.21], [' there', 0.08], ['.', 0.07]], pick: 0 },
  { ctx: 'The cat sat on', c: [[' the', 0.63], [' a', 0.2], [' my', 0.06], [' his', 0.04]], pick: 0 },
  { ctx: 'The cat sat on the', c: [[' mat', 0.31], [' floor', 0.22], [' sofa', 0.1], [' roof', 0.06]], pick: 1 },
  { ctx: 'The cat sat on the floor', c: [['.', 0.55], [',', 0.2], [' and', 0.1], [' again', 0.03]], pick: 0 },
];
slide({
  part: 'Part 0 · The game', title: 'Generation is a loop', holds: [0, 3000, 9500],
  html: `
  <h1>Generation = predict, pick, append, repeat</h1>
  <div class="card" style="margin:22px 0 26px;padding:18px 26px"><h3 style="margin:0 0 6px">Text so far</h3><div class="tape lp-tape" style="font-family:var(--serif);font-size:40px;letter-spacing:0"></div></div>
  <div style="display:grid;grid-template-columns:260px 60px 470px 60px 300px;align-items:center;justify-content:center">
    <div class="card center" style="background:var(--ink);color:#fff;border:none;padding:34px 10px">
      <div style="font-size:15px;letter-spacing:.14em;opacity:.7">1 · PREDICT</div>
      <div style="font-family:var(--serif);font-size:34px;margin-top:4px">language model</div></div>
    <div class="center" style="font-size:40px;color:var(--muted)">→</div>
    <div class="card"><div style="font-size:15px;letter-spacing:.14em;color:var(--muted);margin-bottom:4px">PROBABILITIES</div><div class="lp-bars"></div></div>
    <div class="center" style="font-size:40px;color:var(--muted)">→</div>
    <div class="card center"><div style="font-size:15px;letter-spacing:.14em;color:var(--muted)">2 · PICK ONE (SAMPLE)</div>
      <div class="lp-pick" style="font-family:var(--mono);font-size:40px;color:var(--y);min-height:60px;margin-top:6px"></div>
      <div style="font-size:15px;letter-spacing:.14em;color:var(--muted);margin-top:6px">3 · APPEND ↑ &nbsp; 4 · REPEAT</div></div>
  </div>
  <p class="small muted center" style="margin-top:16px">Illustrative numbers. Notice step 4 picked <b>floor</b>, not the top choice <b>mat</b>: picking means <i>sampling</i>.</p>`,
  init(el, S) { S.it = 0; },
  step(el, k, S) {
    const tape = $(el, '.lp-tape'), bb = $(el, '.lp-bars'), pk = $(el, '.lp-pick');
    const show = (i, phase) => {
      const L = LOOP[Math.min(i, LOOP.length - 1)];
      tape.innerHTML = esc(L.ctx) + (phase >= 2 ? `<span class="new">${esc(L.c[L.pick][0])}</span>` : '') + '<span style="color:var(--y)">▏</span>';
      bb.innerHTML = phase >= 1 ? bars(L.c.map(([t, p], j) => ({ lab: JSON.stringify(t).slice(1, -1), p, color: j === L.pick && phase >= 2 ? 'var(--y)' : '#E9A3B6' })), { scale: 1.4 }) : '';
      pk.textContent = phase >= 2 ? JSON.stringify(L.c[L.pick][0]).slice(1, -1) : '';
    };
    const run = (from, to) => {
      let t = 0;
      for (let i = from; i < to; i++) {
        S.T.later(() => show(i, 0), t); S.T.later(() => show(i, 1), t + 350); S.T.later(() => show(i, 2), t + 1300);
        t += 2200;
      }
      S.T.later(() => { const L = LOOP[LOOP.length - 1]; tape.innerHTML = esc(L.ctx + L.c[L.pick][0]); bb.innerHTML = ''; pk.textContent = ''; }, t);
    };
    if (k === 0) show(0, 0);
    if (k === 1) run(0, 1);
    if (k === 2) run(1, LOOP.length);
  },
  says: [
    'How does a guesser become a writer? Put it in a loop.',
    'Predict a distribution. Pick one token from it. Glue it onto the text. Now the text is one token longer — so predict again.',
    'That loop is the “generative” in generative AI. Notice we sometimes pick a token that is not the most likely one: we sample. Everything else today is about what happens inside the predict box.',
  ],
});

// ───────────────────────────── 4. Two problems + roadmap
slide({
  part: 'Part 0 · The game', title: 'Two problems',
  html: `
  <h1>Two problems before we can build the predict box</h1>
  <div class="row" style="margin-top:22px">
    <div class="col card"><h3>Problem 1</h3><h2>Text isn’t numbers</h2>
      <p>A neural network can only multiply and add. What is <span class="mono">0.5 × "cat"</span>?</p>
      <p class="small muted">→ we need a way to turn text into numbers.</p></div>
    <div class="col card" data-step="1"><h3>Problem 2</h3><h2>Order matters</h2>
      <p><b>hot dog</b> ≠ <b>dog hot</b>. Both contain the same “bag of words” {dog, hot}.</p>
      <p class="small muted">→ the model must know what came before, and in what order.</p></div>
  </div>
  <div data-step="2" style="margin-top:34px">
    <h3>Today’s route</h3>
    <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:14px">
      ${[['1', 'Text → numbers', 'tokens and IDs'], ['2', 'A lookup table', 'the simplest generator'], ['3', 'Memory', 'recurrent neural networks'], ['4', 'Why memory fades', 'vanishing gradients, LSTM'], ['5', 'Recap', 'and Workshop 4']]
        .map(([n, a, b]) => `<div class="card" style="padding:14px 16px"><div style="font-family:var(--serif);font-size:30px;color:var(--h)">${n}</div><div style="font-weight:600;font-size:20px">${a}</div><div class="small muted">${b}</div></div>`).join('')}
    </div>
  </div>`,
  says: [
    'Two problems stand in the way. First: text is not numbers, and a neural network only does arithmetic.',
    'Second: order matters. “Hot dog” and “dog hot” use the same words and mean different things. A model that only counts which words appear would treat them the same.',
    'So here is the route. Turn text into numbers. Build the simplest possible generator, a lookup table. Give it memory. See why that memory fades. Then recap.',
  ],
});

// ───────────────────────────── 5. Tokens (real tokenizer output)
slide({
  part: 'Part 1 · Text → numbers', title: 'Tokens',
  html: `
  <h1>Step one: chop text into <span class="x">tokens</span>, give each an ID</h1>
  <div class="row" style="margin-top:10px">
    <div class="col" style="flex:2.2">
      <div class="btns tk-ex" style="margin-bottom:14px"></div>
      <div class="card" style="min-height:250px"><div class="tk-out"></div></div>
      <div class="btns tk-enc" style="margin-top:14px"></div>
    </div>
    <div class="col stack">
      <div class="card tk-stats" style="font-size:20px;line-height:1.7"></div>
      <div class="assume" data-step="1"><p>The <b>vocabulary is fixed</b> before training: a list of allowed pieces. Every piece has one ID, and every text can be spelled with them.</p></div>
    </div>
  </div>
  <p class="small muted" style="margin-top:12px">Real output of OpenAI’s tokenizers (GPT-2 and GPT-4o), via <span class="mono">tiktoken</span>. <span class="sp">·</span> marks a leading space.</p>`,
  init(el, S) {
    S.ex = 0; S.enc = 'gpt2';
    const D = window.TOKENS;
    if (!D) { $(el, '.tk-out').innerHTML = '<p class="muted">data/tokens.js not loaded</p>'; return; }
    const exs = D.examples;
    $(el, '.tk-ex').innerHTML = exs.map((e, i) => `<button class="btn" data-i="${i}">${esc(e.text.length > 20 ? e.text.slice(0, 17) + '…' : e.text)}</button>`).join('');
    $(el, '.tk-enc').innerHTML = D.encodings.map((e) => `<button class="btn" data-e="${e.key}">${esc(e.name)} · vocab ${e.vocab.toLocaleString()}</button>`).join('');
    $$(el, '.tk-ex .btn').forEach((b) => (b.onclick = () => { S.ex = +b.dataset.i; S.render(); }));
    $$(el, '.tk-enc .btn').forEach((b) => (b.onclick = () => { S.enc = b.dataset.e; S.render(); }));
    S.render = () => {
      const e = exs[S.ex], toks = e.tokens[S.enc];
      $$(el, '.tk-ex .btn').forEach((b) => b.classList.toggle('on', +b.dataset.i === S.ex));
      $$(el, '.tk-enc .btn').forEach((b) => b.classList.toggle('on', b.dataset.e === S.enc));
      $(el, '.tk-out').innerHTML =
        `<div style="font-family:var(--serif);font-size:28px;margin-bottom:14px">${esc(e.text)}</div>` +
        toks.map((t) => `<span class="chip"><span class="p">${esc(t.s).replace(/^ /, '<span class="sp">·</span>').replace(/\n/g, '↵')}</span><span class="id">${t.id}</span></span>`).join('');
      const enc = D.encodings.find((x) => x.key === S.enc);
      $(el, '.tk-stats').innerHTML = `<b>${[...e.text].length}</b> characters → <b class="x">${toks.length}</b> tokens<br>
        Vocabulary: <b>${enc.vocab.toLocaleString()}</b> pieces<br>
        On all of Shakespeare: <b>${enc.chars_per_token.toFixed(2)}</b> characters per token`;
    };
    S.render();
  },
  step(el, k, S) {
    if (!window.TOKENS) return;
    const idx = (label) => Math.max(0, window.TOKENS.examples.findIndex((e) => e.text.startsWith(label)));
    if (k === 0) { S.ex = 0; S.enc = 'gpt2'; }
    if (k === 1) { S.ex = idx('Supercal'); S.enc = 'gpt2'; }
    if (k === 2) { S.ex = idx('1234567'); S.enc = 'gpt2'; }
    if (k === 3) { S.ex = 0; S.enc = window.TOKENS.encodings[1].key; }
    S.render();
  },
  says: [
    'Step one: chop the text into pieces called tokens. This is the real GPT-2 tokenizer. Each piece has an ID number — its position in a fixed vocabulary of about fifty thousand pieces.',
    'Common words, including the space in front of them, are one token. Rare words get split into chunks the vocabulary does contain. Nothing is ever “unknown”: in the worst case, text is spelled out in tiny pieces.',
    'Numbers are chopped in ways that do not respect place value — one reason language models can be clumsy at arithmetic.',
    'Newer tokenizers have bigger vocabularies, so the same text needs fewer tokens. A rule of thumb for English: about four characters per token. Click through the other examples yourself.',
  ],
});

// ───────────────────────────── 6. Three ways to cut
slide({
  part: 'Part 1 · Text → numbers', title: 'Character, word, subword',
  html: `
  <h1>Three ways to cut text</h1>
  <table class="data" style="margin-top:20px;font-size:22px">
    <tr><th></th><th>“unbelievably” becomes</th><th>Vocabulary size</th><th>Tokens per text</th><th>A word never seen before?</th></tr>
    <tr><td>Character</td><td class="mono">u n b e l i e v a b l y</td><td>tiny (~100)</td><td>very many</td><td>always fine</td></tr>
    <tr data-step="1"><td>Word</td><td class="mono">unbelievably</td><td>huge (every form of every word)</td><td>few</td><td>breaks: “unknown”</td></tr>
    <tr data-step="2"><td>Subword</td><td class="mono cw-sub">…</td><td>medium (50k–200k)</td><td>medium</td><td>split into known pieces</td></tr>
  </table>
  <div class="keyidea" data-step="3" style="margin-top:30px"><p>It’s a trade-off between vocabulary size and sequence length. Modern LLMs use subwords. <b>For the rest of today we use characters</b> — the vocabulary is just letters, spaces and punctuation, which keeps every table small enough to see.</p></div>`,
  init(el) {
    const D = window.TOKENS;
    const e = D && D.examples.find((x) => x.text === 'unbelievably');
    $(el, '.cw-sub').textContent = e ? e.tokens.gpt2.map((t) => t.s).join(' · ') + '  (GPT-2)' : 'un · believ · ably';
  },
  says: [
    'There are three common ways to cut text. Characters: a tiny vocabulary, but every text becomes a very long sequence.',
    'Whole words: short sequences, but the vocabulary must contain every form of every word, and anything new breaks it.',
    'Subwords sit in between: frequent words stay whole, rare words split into frequent pieces. That is what GPT-style models use.',
    'Today we use characters. The ideas are identical, and the tables stay small enough to look at.',
  ],
});

// ───────────────────────────── 7. IDs are names; one-hot
slide({
  part: 'Part 1 · Text → numbers', title: 'IDs are names, not amounts',
  html: `
  <h1>An ID is a name, not an amount</h1>
  <div class="row" style="margin-top:16px">
    <div class="col">
      <p>Say our vocabulary is <span class="x mono">a, b, c</span> with IDs <span class="mono">0, 1, 2</span>.</p>
      <svg width="640" height="120" style="margin-top:14px">
        <line x1="40" y1="60" x2="600" y2="60" stroke="#C9C1B0" stroke-width="2"/>
        ${[['a', 0], ['b', 1], ['c', 2]].map(([t, i]) => `<circle cx="${80 + i * 240}" cy="60" r="10" fill="var(--x)"/><text x="${80 + i * 240}" y="36" text-anchor="middle" font-size="24" fill="var(--x)" font-family="JetBrains Mono">${t}</text><text x="${80 + i * 240}" y="100" text-anchor="middle" font-size="18" fill="#8A8F9E">${i}</text>`).join('')}
      </svg>
      <p>If we fed the raw IDs in, the math would think <b>b is halfway between a and c</b>, and that c is “twice” b. Those are accidents of numbering.</p>
    </div>
    <div class="col" data-step="1">
      <p>Fix for today: give each token <b>its own axis</b>. A <i>one-hot</i> vector has a single 1 at the token’s ID.</p>
      <div style="display:flex;gap:40px;margin:20px 0 0 30px">
        ${[['a', [1, 0, 0]], ['b', [0, 1, 0]], ['c', [0, 0, 1]]].map(([t, v]) => `<div class="center"><div class="x mono" style="font-size:26px">${t}</div><div style="margin-top:6px">${v.map((x) => `<div style="width:54px;height:44px;line-height:44px;border:1px solid var(--rule);background:${x ? 'var(--x)' : '#fff'};color:${x ? '#fff' : 'var(--muted)'};font-family:var(--mono);font-size:22px">${x}</div>`).join('')}</div></div>`).join('')}
      </div>
    </div>
  </div>
  <div class="assume" data-step="2" style="margin-top:24px"><p>Every token is a one-hot vector: <b>all tokens are equally different</b> from each other. That is honest but wasteful (“cat” is as far from “dog” as from “carburetor”). Next week: learned <i>embeddings</i> that place similar tokens near each other.</p></div>`,
  says: [
    'We now have ID numbers. But an ID is a name, not an amount. If we fed IDs straight into arithmetic, the model would think b sits halfway between a and c.',
    'The fix we use today: one-hot vectors. Each token gets its own axis — a list of zeros with a single one at the token’s ID.',
    'This is an assumption worth naming: every token is equally different from every other. Next week, embeddings will fix that by learning which tokens are similar.',
  ],
});

// ───────────────────────────── 8. A table is a model (identity)
function mxHTML(P, cls = '') {
  const v = ['a', 'b', 'c'];
  return `<table class="mx ${cls}"><tr><th></th>${v.map((c) => `<th class="x">${c}</th>`).join('')}</tr>
    ${P.map((r, i) => `<tr data-r="${i}"><th class="x">${v[i]}</th>${r.map((p, j) => `<td data-c="${j}" style="background:rgba(214,31,79,${(0.06 + p * 0.5).toFixed(2)})">${p === 1 || p === 0 ? p : p.toFixed(1)}</td>`).join('')}</tr>`).join('')}</table>`;
}
slide({
  part: 'Part 2 · A lookup table', title: 'A table is a model', holds: [0, 3400, 4800],
  html: `
  <h1>The simplest generator: a lookup table</h1>
  <div class="row" style="margin-top:14px;align-items:center">
    <div style="flex:none;position:relative;padding:34px 0 0 44px">
      <div class="axis-l" style="position:absolute;top:0;left:120px">next character →</div>
      <div class="axis-l" style="position:absolute;left:-40px;top:170px;transform:rotate(-90deg)">current ↓</div>
      <div class="idm">${mxHTML([[1, 0, 0], [0, 1, 0], [0, 0, 1]])}</div>
    </div>
    <div class="col stack" style="padding-left:30px">
      <p>A <i>bigram</i> table: row = the current character, column = the next one. Vocabulary: <span class="x mono">a, b, c</span>.</p>
      <p><b>Can you generate some text from it?</b> Try prompts <span class="mono x">a</span>, <span class="mono x">b</span>, <span class="mono x">c</span>.</p>
      <div class="card"><div class="tape id-tape" style="min-height:40px"></div></div>
      <div class="keyidea" data-step="2"><p>A table already <i>is</i> a model: input → lookup → output. This one is deterministic and dull. Next: put <b>probabilities</b> in the cells.</p></div>
    </div>
  </div>`,
  step(el, k, S) {
    const tape = $(el, '.id-tape');
    const rows = $$(el, 'tr[data-r]');
    const hot = (r) => { rows.forEach((tr, i) => { tr.classList.toggle('row-on', i === r); $$(tr, 'td').forEach((td, j) => td.classList.toggle('hot', i === r && j === r)); }); };
    tape.innerHTML = '';
    hot(-1);
    if (k === 0) return;
    const prompts = k === 1 ? ['a'] : ['a', 'b', 'c'];
    let t = 0, text = '';
    prompts.forEach((p, pi) => {
      const r = 'abc'.indexOf(p);
      const start = text + (pi ? '<br>' : '');
      for (let n = 0; n <= 10; n++) {
        const s = start + `<span class="muted">prompt ${p} → </span>` + p.repeat(n + 1);
        S.T.later(() => { tape.innerHTML = s; hot(r); }, t);
        t += k === 1 ? 260 : 120;
      }
      text = start + `<span class="muted">prompt ${p} → </span>` + p.repeat(11);
    });
  },
  says: [
    'Here is the simplest possible generator: a table. Rows are the current character, columns are the next one. Can you generate text from it?',
    'Prompt “a”: look up row a, the 1 is in column a, so the next character is a. Then again, and again.',
    'Same for b and c. A table already is a model — input, lookup, output. This one is deterministic and dull. Let’s put probabilities in the cells instead.',
  ],
});

// ───────────────────────────── 9. Probabilistic table + sampler + code
const P3 = [[0.3, 0.6, 0.1], [0.1, 0.6, 0.3], [0.3, 0.0, 0.7]];
const SEGC = ['#9DBBF5', '#F5C27A', '#9ED8B4'];
const SAMPLER_CODE = `vocab = ['a', 'b', 'c']
P = np.array([[0.3, 0.6, 0.1],   # row a: P(next | a)
              [0.1, 0.6, 0.3],   # row b
              [0.3, 0.0, 0.7]])  # row c

def generate(start, length):
    idx = vocab.index(start)
    out = [start]
    for _ in range(length - 1):
        probs = P[idx]                      # 1. find the row
        idx = np.random.choice(3, p=probs)  # 2. throw the dart
        out.append(vocab[idx])              # 3. append, repeat
    return ''.join(out)`;
slide({
  part: 'Part 2 · A lookup table', title: 'Sampling from a table', holds: [0, 3200, 9200, 6800],
  html: `
  <h1>Put probabilities in the table, then roll dice</h1>
  <div style="display:grid;grid-template-columns:300px 470px 1fr;gap:28px;margin-top:6px">
    <div>
      <div style="position:relative;padding:28px 0 0 0"><div class="axis-l" style="position:absolute;top:0;left:60px">next →</div>${mxHTML(P3)}</div>
      <div class="assume" style="margin-top:16px"><p>Each row is a probability distribution: no negatives, and it <b>sums to 1</b>.</p></div>
    </div>
    <div class="stack">
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:baseline"><h3 style="margin:0">Current character</h3><div class="sm-cur x mono" style="font-size:44px;line-height:1">a</div></div>
        <div style="position:relative;height:120px;margin-top:10px">
          <div class="sm-bar" style="position:absolute;top:36px;left:0;right:0;height:46px;display:flex;border-radius:8px;overflow:hidden"></div>
          <div class="sm-ticks" style="position:absolute;top:88px;left:0;right:0;font-family:var(--mono);font-size:14px;color:var(--muted)"></div>
          <div class="sm-dart" style="position:absolute;top:0;left:0;transition:left .55s cubic-bezier(.2,.8,.2,1),opacity .3s;opacity:0;transform:translateX(-50%);text-align:center">
            <div class="sm-r mono" style="font-size:15px;color:var(--y)"></div><div style="width:0;height:0;border-left:9px solid transparent;border-right:9px solid transparent;border-top:14px solid var(--y);margin:0 auto"></div></div>
        </div>
      </div>
      <div class="card"><h3>Generated</h3><div class="tape sm-tape" style="min-height:80px;font-size:24px"></div></div>
      <div class="btns" style="flex-wrap:nowrap;gap:6px"><button class="btn sm-step">Step</button><button class="btn sm-run">Run ×40</button><button class="btn sm-reset">Reset</button>
        <span style="margin-left:6px;align-self:center;font-size:15px;color:var(--muted)">start</span>${['a', 'b', 'c'].map((c) => `<button class="btn sm-start" data-c="${c}" style="padding:8px 11px">${c}</button>`).join('')}</div>
    </div>
    <div class="sm-code"></div>
  </div>`,
  init(el, S) {
    $(el, '.sm-code').innerHTML = U.code(SAMPLER_CODE).replace('class="code"', 'class="code" style="font-size:14.5px"');
    S.pre = $(el, '.sm-code pre');
    S.reset = (c = 'a') => { S.cur = 'abc'.indexOf(c); S.out = c; S.rng = mulberry32(7); S.draw(-1); U.hlLines(S.pre, [7, 8]); };
    S.draw = (hl, r) => {
      const row = P3[S.cur];
      $(el, '.sm-cur').textContent = 'abc'[S.cur];
      $(el, '.sm-bar').innerHTML = row.map((p, j) => (p > 0 ? `<div style="width:${p * 100}%;background:${SEGC[j]};display:flex;align-items:center;justify-content:center;font-family:var(--mono);font-size:19px;${hl === j ? 'box-shadow:inset 0 0 0 3px var(--y);' : ''}">${'abc'[j]} ${p}</div>` : '')).join('');
      let acc = 0;
      $(el, '.sm-ticks').innerHTML = [0, ...row].map((p, j) => { acc += j ? p : 0; return `<span style="position:absolute;left:${acc * 100}%;transform:translateX(-50%)">${acc.toFixed(1)}</span>`; }).join('');
      $$(el, 'table.mx tr[data-r]').forEach((tr, i) => { tr.classList.toggle('row-on', i === S.cur); $$(tr, 'td').forEach((td, j) => td.classList.toggle('hot', i === S.cur && j === hl)); });
      const d = $(el, '.sm-dart');
      if (r == null) d.style.opacity = 0; else { d.style.opacity = 1; d.style.left = r * 100 + '%'; $(el, '.sm-r').textContent = 'r = ' + r.toFixed(2); }
      const t = S.out;
      $(el, '.sm-tape').innerHTML = esc(t.slice(0, -1)) + `<span class="new">${esc(t.slice(-1))}</span>`;
    };
    S.one = (slow, t0 = 0) => {
      const r = S.rng();
      const j = pick(P3[S.cur], r);
      if (!slow) { S.cur = j; S.out += 'abc'[j]; S.draw(-1); U.hlLines(S.pre, [9]); return t0; }
      S.T.later(() => { S.draw(-1); U.hlLines(S.pre, [10]); }, t0);
      S.T.later(() => { S.draw(-1, r); U.hlLines(S.pre, [11]); }, t0 + 700);
      S.T.later(() => { S.draw(j, r); }, t0 + 1400);
      S.T.later(() => { S.out += 'abc'[j]; S.draw(j, r); U.hlLines(S.pre, [12]); }, t0 + 1900);
      S.T.later(() => { S.cur = j; S.draw(-1); U.hlLines(S.pre, [9]); }, t0 + 2600);
      return t0 + 2900;
    };
    S.oneSync = () => { const r = S.rng(); const j = pick(P3[S.cur], r); S.cur = j; S.out += 'abc'[j]; };
    S.runFast = (n) => { for (let i = 0; i < n; i++) S.T.later(() => { S.oneSync(); S.draw(-1); }, i * 110); };
    $(el, '.sm-step').onclick = () => { S.T.clear(); S.one(true); };
    $(el, '.sm-run').onclick = () => { S.T.clear(); S.runFast(40); };
    $(el, '.sm-reset').onclick = () => { S.T.clear(); S.reset('abc'[S.start || 0]); };
    $$(el, '.sm-start').forEach((b) => (b.onclick = () => { S.T.clear(); S.start = 'abc'.indexOf(b.dataset.c); S.reset(b.dataset.c); }));
    S.reset('a');
  },
  step(el, k, S) {
    // deterministic replay so each step shows the same thing every time
    S.reset('a');
    if (k === 1) S.one(true);
    if (k === 2) { S.oneSync(); S.draw(-1); let t = 300; for (let i = 0; i < 3; i++) t = S.one(true, t); }
    if (k === 3) { for (let i = 0; i < 4; i++) S.oneSync(); S.draw(-1); S.runFast(56); }
  },
  says: [
    'Now each cell holds a probability. Row a says: after an a, the next character is a 30% of the time, b 60%, c 10%. Every row adds up to one.',
    'To generate: take the current character’s row and lay its probabilities end to end on a line from 0 to 1. Throw a dart — a random number r. The segment it lands in is the next character.',
    'Then that character becomes the current one, and we repeat. Follow the highlighted code on the right: it is exactly this loop. The line with np.random.choice is the dart.',
    'Run it longer. You see long runs of b’s and c’s: the big numbers on the diagonal, 0.6 and 0.7, mean those characters like to repeat. The output’s statistics mirror the table.',
  ],
});

// ───────────────────────────── 10. Greedy vs sampling
slide({
  part: 'Part 2 · A lookup table', title: 'Why roll dice?',
  html: `
  <h1>Why roll dice? Why not always take the top choice?</h1>
  <div class="row" style="margin-top:14px">
    <div style="flex:none">${mxHTML(P3)}</div>
    <div class="col stack">
      <div class="card"><h3>Greedy: always the most likely next character</h3><div class="tape gr-g" style="font-size:24px"></div></div>
      <div class="card" data-step="1"><h3>Sampling: roll the dice — three runs, same start</h3><div class="tape gr-s" style="font-size:24px"></div></div>
      <div class="keyidea" data-step="2"><p>Greedy decoding gets stuck in loops. Sampling keeps variety — it is why the same prompt can give different answers each time. <b>Temperature</b> (Part 3) is a dial between the two.</p></div>
    </div>
  </div>`,
  init(el) {
    const greedy = (s, n) => { let i = 'abc'.indexOf(s), o = s; for (let t = 0; t < n; t++) { i = P3[i].indexOf(Math.max(...P3[i])); o += 'abc'[i]; } return o; };
    $(el, '.gr-g').innerHTML = `<span class="muted">from a:</span> ${greedy('a', 36)}<br><span class="muted">from c:</span> ${greedy('c', 36)}`;
    const samp = (seed) => { const r = mulberry32(seed); let i = 0, o = 'a'; for (let t = 0; t < 36; t++) { i = pick(P3[i], r()); o += 'abc'[i]; } return o; };
    $(el, '.gr-s').innerHTML = [3, 11, 29].map((s) => `<span class="muted">from a:</span> ${samp(s)}`).join('<br>');
  },
  says: [
    'Why roll dice at all? Try always taking the most likely character. From a, the top choice is b; from b, the top choice is b again. So: a, b, b, b, b, forever. From c, it’s c forever.',
    'Sampling from the same table gives a different string every run, but each one has the same statistics.',
    'Always choosing the top option collapses into loops — real language models do this too. Later we’ll meet temperature, a dial between greedy and wild.',
  ],
});

// ───────────────────────────── 11. Counting a real bigram table
slide({
  part: 'Part 2 · A lookup table', title: 'Where the numbers come from', holds: [12500, 6000, 3600, 0],
  html: `
  <h1>Where do the probabilities come from? <span class="h">Counting.</span></h1>
  <div style="display:grid;grid-template-columns:560px 1fr;gap:40px;margin-top:4px">
    <div>
      <canvas class="bg-heat" width="1080" height="1080" style="width:540px;height:540px;cursor:crosshair"></canvas>
    </div>
    <div class="stack">
      <div class="card" data-step="0-0"><h3>Slide a two-character window over Shakespeare</h3><div class="bg-win mono" style="font-size:26px;line-height:1.6;word-break:break-all"></div><div class="bg-cnt mono" style="font-size:20px;margin-top:8px;color:var(--ink2)"></div></div>
      <div class="card" data-step="1"><h3>Row <span class="bg-rowname x mono"></span>: what follows it (click any row)</h3><div class="bg-bars"></div></div>
      <div class="card" data-step="2"><h3>Generated from this table</h3><div class="gen bg-gen" style="border:none;padding:0;min-height:120px;font-size:19px"></div></div>
      <div class="keyidea" data-step="3"><p>Locally plausible, globally nonsense: it has never seen more than <b>one</b> character of context.</p></div>
    </div>
  </div>`,
  init(el, S) {
    const B = window.BIGRAM && window.BIGRAM.bigram27;
    if (!B) { $(el, '.bg-win').textContent = 'data/bigram.js not loaded'; return; }
    const L = B.labels, C = B.counts, n = L.length;
    const cv = $(el, '.bg-heat'), g = cv.getContext('2d');
    const cell = 1080 / (n + 1.2), off = cell * 1.2;
    const mx = Math.max(...C.flat());
    S.drawHeat = (row) => {
      g.clearRect(0, 0, 1080, 1080);
      g.font = `${cell * 0.62}px JetBrains Mono`; g.textAlign = 'center'; g.textBaseline = 'middle';
      for (let i = 0; i < n; i++) {
        g.fillStyle = '#2563EB';
        g.fillText(L[i] === ' ' ? '␣' : L[i], off / 2, off + (i + 0.5) * cell);
        g.fillText(L[i] === ' ' ? '␣' : L[i], off + (i + 0.5) * cell, off / 2);
        for (let j = 0; j < n; j++) {
          const v = Math.sqrt(C[i][j] / (C[i].reduce((a, b) => a + b, 0) || 1));
          g.fillStyle = `rgba(214,31,79,${(0.03 + 0.97 * v).toFixed(3)})`;
          g.fillRect(off + j * cell + 1, off + i * cell + 1, cell - 2, cell - 2);
        }
      }
      if (row != null) { g.strokeStyle = '#2563EB'; g.lineWidth = 5; g.strokeRect(off, off + row * cell, n * cell, cell); }
    };
    S.showRow = (i) => {
      S.row = i; S.drawHeat(i);
      const tot = C[i].reduce((a, b) => a + b, 0);
      const top = C[i].map((c, j) => [j, c]).filter((x) => x[1] > 0).sort((a, b) => b[1] - a[1]).slice(0, 6);
      $(el, '.bg-rowname').textContent = L[i] === ' ' ? '␣ (space)' : L[i];
      $(el, '.bg-bars').innerHTML = bars(top.map(([j, c]) => ({ lab: L[j] === ' ' ? '␣' : L[j], p: c / tot, num: `${c.toLocaleString()}` })), { scale: 1 });
    };
    cv.onclick = (e) => { const r = cv.getBoundingClientRect(); const y = ((e.clientY - r.top) / r.height) * 1080; const i = Math.floor((y - off) / cell); if (i >= 0 && i < n) S.showRow(i); };
    S.P = C.map((r) => { const t = r.reduce((a, b) => a + b, 0) || 1; return r.map((c) => c / t); });
    S.drawHeat(null);
  },
  step(el, k, S) {
    const B = window.BIGRAM && window.BIGRAM.bigram27;
    if (!B) return;
    const L = B.labels;
    if (k === 0) {
      const txt = 'first citizen: before we proceed any further, hear me speak.';
      let cnt = {};
      S.drawHeat(null);
      for (let i = 0; i < txt.length - 1; i++) {
        S.T.later(() => {
          const pair = txt.slice(i, i + 2);
          cnt[pair] = (cnt[pair] || 0) + 1;
          $(el, '.bg-win').innerHTML = esc(txt.slice(0, i)) + `<span style="background:var(--x-bg);color:var(--x);border-radius:4px;outline:2px solid var(--x)">${esc(pair).replace(/ /g, '␣')}</span>` + `<span class="muted">${esc(txt.slice(i + 2))}</span>`;
          $(el, '.bg-cnt').innerHTML = `count[<span class="x">${showChar(pair[0])}</span> → <span class="y">${showChar(pair[1])}</span>] += 1`;
        }, 400 + i * 190);
      }
    }
    if (k >= 1) S.showRow(k === 1 ? L.indexOf('t') : S.row ?? L.indexOf('t'));
    if (k === 1) S.T.later(() => S.showRow(L.indexOf('q')), 5200);
    if (k === 2) {
      S.showRow(L.indexOf('q'));
      const r = mulberry32(5); let i = L.indexOf('t'), out = 't';
      for (let t = 0; t < 260; t++) { i = pick(S.P[i], r()); out += L[i]; }
      const box = $(el, '.bg-gen');
      box.textContent = '';
      for (let t = 1; t <= out.length; t += 3) S.T.later(() => (box.textContent = out.slice(0, t)), t * 12);
    }
  },
  says: [
    'Where do the probabilities come from? The simplest answer: count. Slide a two-character window along real text — here, all of Shakespeare — and tally every pair.',
    'Here are all 27 by 27 counts, for lowercase letters plus space. Darker means more common. After a t, the most common next character is h. After a q, almost always u.',
    'Divide each row by its total and you have a transition table — a real language model, trained on real text. Training here is just counting. Let’s generate from it.',
    'Locally plausible, globally nonsense. Pairs of letters look like English, words don’t. It has never seen more than one character of context.',
  ],
});

// ───────────────────────────── 12. Markov assumption and the explosion
slide({
  part: 'Part 2 · A lookup table', title: 'The Markov assumption',
  html: `
  <h1>The hidden assumption, and why bigger tables fail</h1>
  <div class="assume" style="margin-top:8px"><p><b>Markov assumption:</b> the next token depends <i>only</i> on the current token.</p></div>
  <p class="lede" style="margin:24px 0 8px;font-size:34px!important"><span class="mk-w">The pink elephant tried to get into the car but it was</span> <b class="x">too</b> <span style="display:inline-block;width:90px;border-bottom:3px solid var(--y)"></span></p>
  <p class="small muted" data-step="0">What a bigram table sees. To know <i>what</i> is too big, you need “elephant”, 9 words back.</p>
  <div class="row" data-step="1" style="margin-top:14px">
    <div class="col">
      <table class="data" style="font-size:21px">
        <tr><th>Context remembered (k tokens)</th><th>Rows, 27 characters</th><th>Rows, 50,257 GPT-2 tokens</th></tr>
        <tbody class="mk-rows"></tbody>
      </table>
    </div>
    <div class="col stack" style="flex:.8">
      <p>Remembering <b>k</b> tokens needs one row for every possible k-token context: <span style="font-family:var(--serif);font-size:30px">V<sup>k</sup></span> rows.</p>
      <p data-step="2">Worse: almost all of those rows <b>never appear</b> in any training text, so their counts are zero.</p>
      <div class="keyidea" data-step="3"><p>We need memory that is <b>compressed</b>: a fixed-size summary of everything so far, updated one token at a time.</p></div>
    </div>
  </div>`,
  init(el) {
    const f = (v, k) => { const x = Math.pow(v, k); return x < 1e9 ? Math.round(x).toLocaleString() : `${(x / 10 ** Math.floor(Math.log10(x))).toFixed(1)} × 10<sup>${Math.floor(Math.log10(x))}</sup>`; };
    $(el, '.mk-rows').innerHTML = [1, 2, 3, 5, 10].map((k) => `<tr><td>${k}</td><td class="mono">${f(27, k)}</td><td class="mono">${f(50257, k)}</td></tr>`).join('');
  },
  step(el, k) { $(el, '.mk-w').style.opacity = k === 0 ? 0.22 : 0.22; },
  says: [
    'The table has a hidden assumption, called the Markov assumption: the next token depends only on the current one. Here, a bigram model sees only “too”. It has no idea an elephant was ever mentioned.',
    'The obvious fix — condition on more previous tokens — explodes. Each extra token of context multiplies the number of rows by the vocabulary size. Ten tokens of GPT-2 vocabulary: ten to the forty-seven rows.',
    'And even if we could store it, almost every row would have zero counts, because those exact contexts never occur in any text.',
    'So we need a different kind of memory: a compressed, fixed-size summary of everything read so far, updated one token at a time. That is a recurrent neural network.',
  ],
});
})();
