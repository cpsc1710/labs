/* Adapter: turns the build outputs in data/ into the small LM interface the slides use. */
(function () {
  // ---- tokens: normalise to {examples:[{text, tokens:{key:[{id,s}]}}], encodings:[{key,name,vocab,chars_per_token}]}
  if (window.TOKENS && !window.TOKENS.__norm) {
    const T = window.TOKENS;
    const names = { gpt2: 'GPT-2', o200k_base: 'GPT-4o' };
    const keys = Object.keys(T.encodings);
    const piece = (t) => (t.complete_utf8 === false ? t.bytes.map((b) => '\\x' + b.toString(16).padStart(2, '0')).join('') : t.piece);
    window.TOKENS = {
      __norm: true,
      encodings: keys.map((k) => ({ key: k, name: names[k] || k, vocab: T.encodings[k].vocab_size, chars_per_token: T.encodings[k].chars_per_token_shakespeare })),
      examples: T.examples.map((e) => ({ text: e.text, tokens: Object.fromEntries(keys.map((k) => [k, e[k].map((t) => ({ id: t.id, s: piece(t) }))])) })),
    };
  }

  const LM = (window.LM = { ok: false });
  const R = window.RNN_DATA, RT = window.RNNRuntime;
  if (!R || !RT) return;
  LM.ok = true;
  LM.vocab = R.vocab;
  LM.H = R.H;
  LM.nParams = R.H * R.V + R.H * R.H + R.H + R.V * R.H + R.V;
  LM.ckpts = R.checkpoints.map((c) => ({ step: c.step, train: c.train_loss, val: c.val_loss }));
  const cache = {};
  const model = (i) => (cache[i] = cache[i] || RT.loadCheckpoint(R, i));
  const idx = (ch) => { const i = R.vocab.indexOf(ch); return i < 0 ? R.vocab.indexOf(' ') : i; };

  function readCtx(m, ctx) {
    let h = RT.zeros(m.H);
    for (const ch of ctx) h = RT.step(m, h, idx(ch));
    return h;
  }
  LM.next = ({ ck, ctx, T = 1 }) => {
    const m = model(ck);
    return Array.from(RT.softmax(RT.logits(m, readCtx(m, ctx)), T));
  };
  LM.gen = ({ ck, seed, n, T = 1, rseed = 1 }) => {
    const m = model(ck), rng = U.mulberry32(rseed * 9973 + ck);
    let h = readCtx(m, seed), out = '';
    for (let t = 0; t < n; t++) {
      const p = RT.softmax(RT.logits(m, h), T);
      const j = U.pick(p, rng());
      out += R.vocab[j];
      h = RT.step(m, h, j);
    }
    return out;
  };

  // ---- bigram over the same vocabulary
  const B = window.BIGRAM;
  if (B && B.bigramFull) {
    const P = B.bigramFull.probs, bv = B.bigramFull.vocab || R.vocab;
    LM.bigram = {
      val: (B.val_loss && B.val_loss.nats_per_char) || B.bigramFull.val_loss,
      gen: ({ seed, n, rseed = 1 }) => {
        const rng = U.mulberry32(rseed * 7919 + 3);
        let i = Math.max(0, bv.indexOf(seed[seed.length - 1])), out = '';
        for (let t = 0; t < n; t++) {
          const row = P[i], s = row.reduce((a, b) => a + b, 0);
          i = U.pick(row.map((v) => v / s), rng());
          out += bv[i];
        }
        return out;
      },
    };
  }

  // ---- hidden states
  const Hd = window.HIDDEN;
  if (Hd) {
    const q = RT.decodeInt8 ? RT.decodeInt8(Hd.states.data) : null;
    const H = Hd.H, n = Hd.T;
    const get = (u, i) => q[i * H + u] / 127;
    const vari = [...Array(H).keys()].map((u) => { let s = 0, s2 = 0; for (let i = 0; i < n; i++) { const v = get(u, i); s += v; s2 += v * v; } return [u, s2 / n - (s / n) ** 2]; });
    LM.hidden = {
      text: Hd.passage, units: H, get,
      order: vari.sort((a, b) => b[1] - a[1]).map((x) => x[0]),
      interp: (Hd.interpretable_units || [])
        .map((d) => ({ unit: d.unit, r: d.correlation, desc: /newline/.test(d.feature_desc) ? 'position in the line' : /speaker/.test(d.feature_desc) ? 'switches off on speaker names' : /uppercase/.test(d.feature_desc) ? 'uppercase letters' : d.feature_desc }))
        .sort((a, b) => ['position in the line', 'switches off on speaker names', 'uppercase letters'].indexOf(a.desc) - ['position in the line', 'switches off on speaker names', 'uppercase letters'].indexOf(b.desc)),
    };
  }

  // ---- gradients
  const G = window.GRADIENTS;
  if (G) {
    const pickStat = (o) => o.loss_grad.median;
    const rel = (a) => a.map((v) => v / a[0]);
    LM.grad = { ks: G.k, trained: rel(pickStat(G.final)), init: G.init ? rel(pickStat(G.init)) : null, note: 'The untrained network (dashed) loses the signal far faster; training pushes back, but cannot escape the repeated product.' };
  }
})();
