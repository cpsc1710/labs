/* Part 3 (live model), Part 4 (why memory fades), Part 5 (recap) */
(function () {
const { $, $$, esc, bars, mulberry32, pick, showChar, lineSVG } = U;
const need = (el, what) => { el.insertAdjacentHTML('beforeend', `<p class="muted" style="position:absolute;bottom:20px">(${what} not loaded)</p>`); };

// ───────────────────────────── 19. Training: every position is a quiz
slide({
  part: 'Part 3 · Memory', title: 'How the weights are learned', holds: [4200, 0, 0],
  html: `
  <h1>Training: the text is its own answer key</h1>
  <div class="row" style="margin-top:8px">
    <div class="col stack">
      <h3>Every position is a quiz</h3>
      <div class="card tr-pairs mono" style="font-size:24px;line-height:1.6;min-height:300px"></div>
      <p class="small">No human labels needed, so a language model can train on as much text as exists.</p>
    </div>
    <div class="col stack" data-step="1">
      <h3>The score: surprise = −log p(correct next character)</h3>
      <div class="tr-curve"></div>
    </div>
  </div>
  <div class="keyidea" data-step="2" style="margin-top:12px"><p><b>Loss</b> = average surprise over every position. <b>Gradient descent</b> (weeks 2–3) nudges <i>every</i> weight — W<sub>x</sub>, W<sub>h</sub>, W<sub>y</sub>, b, c — a little in the direction that lowers it. Fun fact: for a lookup table, the best possible answer to this same problem is exactly <b>counting</b>.</p></div>`,
  init(el) {
    const pts = []; for (let p = 0.005; p <= 1.0001; p += 0.005) pts.push([p, -Math.log(p)]);
    let svg = lineSVG({ w: 640, h: 330, xmax: 1, ymin: 0, ymax: 5.5, series: [{ pts, color: 'var(--y)' }], xlab: 'probability the model gave to the correct character', ylab: 'surprise (nats)', ticksY: [0, 1, 2, 3, 4, 5] });
    const L = 60, W = 640 - 60 - 16, T = 16, H = 330 - 16 - 42;
    const marks = [[0.9, '90% sure: 0.11'], [0.5, 'coin flip: 0.69'], [0.1, '10%: 2.3'], [0.01, '1%: 4.6']];
    svg = svg.replace('</svg>', marks.map(([p, t]) => { const x = L + p * W, y = T + (1 - -Math.log(p) / 5.5) * H; return `<circle cx="${x}" cy="${y}" r="6" fill="var(--y)"/><text x="${x + (p > 0.6 ? -10 : 12)}" y="${y - 10}" text-anchor="${p > 0.6 ? 'end' : 'start'}" font-size="16" fill="var(--ink)">${t}</text>`; }).join('') + '</svg>');
    $(el, '.tr-curve').innerHTML = svg;
  },
  step(el, k, S) {
    const txt = 'ROMEO:\nBut, soft!', box = $(el, '.tr-pairs');
    const row = (i) => `<span class="x">${esc(txt.slice(0, i)).replace(/\n/g, '↵')}</span> <span class="muted">→</span> <span class="y">${showChar(txt[i])}</span>`;
    const all = []; for (let i = 1; i < txt.length; i++) all.push(row(i));
    box.innerHTML = k === 0 ? '' : all.slice(0, 9).join('<br>');
    if (k === 0) all.slice(0, 9).forEach((r, i) => S.T.later(() => (box.innerHTML = all.slice(0, i + 1).join('<br>')), 300 + i * 450));
  },
  says: [
    'How do we find good weights? Take any text. Every position in it is a free quiz: given everything so far, what comes next? The text is its own answer key — which is why language models can train on so much of it.',
    'The score for each quiz is the surprise: minus the log of the probability the model gave to the correct answer. Ninety percent sure and right: surprise 0.11. One percent: 4.6. Certain and right: zero.',
    'The loss is the average surprise. Gradient descent, from weeks two and three, nudges every weight in the direction that lowers it. And a neat fact: for a lookup table, the best solution to this exact problem is counting.',
  ],
});

// ───────────────────────────── 20. Watch it learn (live RNN)
slide({
  part: 'Part 3 · Memory', title: 'Watch it learn', holds: [1500, 1500, 1500, 1500, 1500, 1500],
  html: `
  <h1>A real RNN, trained on Shakespeare, running live in this page</h1>
  <div style="display:grid;grid-template-columns:520px 1fr;gap:34px;margin-top:4px">
    <div class="stack">
      <div class="wl-chart"></div>
      <div class="btns wl-ck"></div>
      <p class="small wl-meta"></p>
    </div>
    <div class="stack">
      <div class="gen wl-out" style="height:430px"></div>
      <div style="display:flex;gap:14px;align-items:center">
        <button class="btn wl-go">Generate again</button>
        <div class="slider" style="grid-template-columns:40px 220px 50px;flex:none"><span class="lab">T</span><input type="range" min="0.1" max="2" step="0.1" class="wl-t"><span class="val wl-tv"></span></div>
        <button class="btn wl-bi">Bigram, for comparison</button>
      </div>
    </div>
  </div>`,
  init(el, S) {
    if (!window.LM || !LM.ok) return need(el, 'data/rnn.js');
    S.ck = LM.ckpts.length - 1; S.T_ = 0.8; S.mode = 'rnn'; S.seed = 1;
    $(el, '.wl-ck').innerHTML = LM.ckpts.map((c, i) => `<button class="btn" data-i="${i}">step ${c.step.toLocaleString()}</button>`).join('');
    $$(el, '.wl-ck .btn').forEach((b) => (b.onclick = () => { S.ck = +b.dataset.i; S.mode = 'rnn'; S.gen(); }));
    $(el, '.wl-go').onclick = () => { S.seed++; S.gen(); };
    $(el, '.wl-bi').onclick = () => { S.mode = 'bigram'; S.gen(); };
    $(el, '.wl-t').oninput = (e) => { S.T_ = +e.target.value; S.gen(); };
    S.chart = () => {
      const xs = LM.ckpts.map((c) => Math.log10(c.step + 1));
      const xmax = Math.max(...xs) * 1.02, ymax = Math.ceil(Math.max(...LM.ckpts.map((c) => c.val)) * 2) / 2 + 0.2;
      const pts = LM.ckpts.map((c, i) => [xs[i], c.val]);
      let svg = lineSVG({ w: 520, h: 330, xmax, ymin: 1, ymax, series: [{ pts: [[0, LM.bigram.val], [xmax, LM.bigram.val]], color: 'var(--muted)', dash: '6 6', width: 2 }, { pts, color: 'var(--h)' }], xlab: 'training steps (log scale: 1, 10, 100, 1k, 10k)', ylab: 'surprise on unseen text (nats/char)', ticksY: [1, 2, 3, 4].filter((t) => t < ymax) });
      const L = 60, W = 520 - 76, T = 16, H = 330 - 58;
      svg = svg.replace('</svg>', pts.map(([x, y], i) => `<circle cx="${L + (x / xmax) * W}" cy="${T + (1 - (y - 1) / (ymax - 1)) * H}" r="${i === S.ck ? 9 : 5}" fill="${i === S.ck ? 'var(--y)' : 'var(--h)'}"/>`).join('') +
        `<text x="${L + W - 6}" y="${T + (1 - (LM.bigram.val - 1) / (ymax - 1)) * H - 8}" text-anchor="end" font-size="15" fill="#8A8F9E">bigram table: ${LM.bigram.val.toFixed(2)}</text></svg>`);
      $(el, '.wl-chart').innerHTML = svg;
    };
    S.gen = () => {
      S.T.clear();
      $$(el, '.wl-ck .btn').forEach((b) => b.classList.toggle('on', S.mode === 'rnn' && +b.dataset.i === S.ck));
      $(el, '.wl-bi').classList.toggle('on', S.mode === 'bigram');
      $(el, '.wl-t').value = S.T_; $(el, '.wl-tv').textContent = S.T_.toFixed(1);
      S.chart();
      const seed = 'ROMEO:\n';
      const out = S.mode === 'rnn' ? LM.gen({ ck: S.ck, seed, n: 420, T: S.T_, rseed: S.seed }) : LM.bigram.gen({ seed, n: 420, rseed: S.seed });
      const c = LM.ckpts[S.ck];
      $(el, '.wl-meta').innerHTML = S.mode === 'rnn'
        ? `Checkpoint after <b>${c.step.toLocaleString()}</b> steps · surprise on unseen text <b class="h">${c.val.toFixed(2)}</b> nats/char · ${LM.H} memory units · ${LM.nParams.toLocaleString()} weights`
        : `Bigram table from the same text · surprise <b>${LM.bigram.val.toFixed(2)}</b> nats/char · ${LM.vocab.length}² = ${(LM.vocab.length ** 2).toLocaleString()} numbers`;
      const box = $(el, '.wl-out');
      const full = seed + out;
      box.innerHTML = '';
      for (let t = seed.length; t <= full.length; t += 4) S.T.later(() => (box.innerHTML = `<b>${esc(seed)}</b>${esc(full.slice(seed.length, t))}`), (t - seed.length) * 6);
    };
    S.chart();
  },
  step(el, k, S) {
    if (!window.LM || !LM.ok) return;
    const n = LM.ckpts.length;
    S.T_ = 0.8; S.seed = 1; S.mode = 'rnn';
    S.ck = [n - 1, 0, Math.min(2, n - 1), Math.min(3, n - 1), n - 1, n - 1][k];
    if (k === 5) S.mode = 'bigram';
    S.gen();
  },
  says: [
    () => `This is a real recurrent network — ${window.LM && LM.ok ? LM.H : 256} memory units — trained on the complete works of Shakespeare on a laptop, and running live in this page. The plot shows its surprise on text it never saw during training.`,
    'At step zero the weights are random. Every character is about equally likely, so the output is noise.',
    'After a few hundred steps it has learned the easy statistics: spaces, common letters, short fragments.',
    'A thousand steps in, real words start to appear, and line breaks.',
    'Fully trained, it has speaker names in capitals, line breaks, punctuation and the rhythm of verse. It knows spelling and format. It does not know meaning.',
    'For comparison, the bigram table trained on exactly the same text. The dashed line is its surprise. The RNN does better because its memory reaches further back than one character.',
  ],
});

// ───────────────────────────── 21. Temperature
slide({
  part: 'Part 3 · Memory', title: 'Temperature', holds: [1200, 1400, 1400, 1400],
  html: `
  <h1>One last knob: <span class="y">temperature</span></h1>
  <div class="eq" style="margin:0 0 10px"><span class="y">p</span> = softmax( <span class="y">scores</span> ÷ <b>T</b> )</div>
  <div style="display:grid;grid-template-columns:560px 1fr;gap:36px">
    <div class="stack">
      <p class="small">The live model’s next-character probabilities after <span class="mono x tp-ctx"></span></p>
      <div class="tp-bars"></div>
      <div class="slider" style="grid-template-columns:40px 1fr 60px"><span class="lab">T</span><input type="range" min="0.1" max="2" step="0.05" class="tp-t"><span class="val tp-tv"></span></div>
    </div>
    <div class="stack"><div class="gen tp-out" style="height:440px"></div></div>
  </div>`,
  init(el, S) {
    if (!window.LM || !LM.ok) return need(el, 'data/rnn.js');
    S.ctx = 'ROMEO:\nI will ';
    $(el, '.tp-ctx').textContent = JSON.stringify(S.ctx).slice(1, -1);
    S.render = (T) => {
      S.Tv = T;
      $(el, '.tp-t').value = T; $(el, '.tp-tv').textContent = T.toFixed(2);
      const p = LM.next({ ck: LM.ckpts.length - 1, ctx: S.ctx, T });
      const top = p.map((v, i) => [i, v]).sort((a, b) => b[1] - a[1]).slice(0, 8);
      $(el, '.tp-bars').innerHTML = bars(top.map(([i, v]) => ({ lab: showChar(LM.vocab[i]), p: v, num: (v * 100).toFixed(1) + '%' })));
      const out = LM.gen({ ck: LM.ckpts.length - 1, seed: 'ROMEO:\n', n: 300, T, rseed: 4 });
      $(el, '.tp-out').innerHTML = `<span class="tag">T = ${T.toFixed(2)}</span>\n<b>ROMEO:\n</b>${esc(out)}`;
    };
    $(el, '.tp-t').oninput = (e) => S.render(+e.target.value);
  },
  step(el, k, S) {
    if (!window.LM || !LM.ok) return;
    const target = [1.0, 0.3, 1.6, 0.8][k];
    const from = S.Tv ?? 1.0;
    for (let i = 0; i <= 12; i++) S.T.later(() => S.render(from + ((target - from) * i) / 12), i * 90);
  },
  says: [
    'One more knob. Before softmax, divide every score by a number T, the temperature. At T equals one, nothing changes.',
    'T below one exaggerates the differences: the top choice takes nearly everything. Output becomes safe and repetitive. As T goes to zero, this becomes greedy decoding.',
    'T above one flattens the differences: rare characters get more chances. Output becomes more surprising, and eventually gibberish.',
    'Chatbots expose this knob too. And the tiny_rnn.py code in Workshop 4 prints samples at several temperatures — now you know what it is doing.',
  ],
});

// ───────────────────────────── 22. Peek inside the memory
slide({
  part: 'Part 3 · Memory', title: 'Inside the memory',
  html: `
  <h1>Inside the memory while it reads</h1>
  <p class="small">The trained model reading a passage it never saw in training. Each row: one of its memory numbers. Each column: one character. <span class="h">Amber</span> = positive, <span style="color:#3E4458">dark</span> = negative.</p>
  <canvas class="hd-heat" width="2840" height="360" style="width:1420px;height:180px;margin-top:8px;border-radius:8px"></canvas>
  <div class="btns hd-units" style="margin:12px 0"></div>
  <div class="card hd-text mono" style="font-size:20px;line-height:1.75;white-space:pre-wrap;height:250px;overflow:hidden"></div>`,
  init(el, S) {
    if (!window.LM || !LM.hidden) return need(el, 'data/hidden.js');
    const Hd = LM.hidden, n = Hd.text.length, U_ = Math.min(64, Hd.units);
    const cv = $(el, '.hd-heat'), g = cv.getContext('2d');
    const cw = 2840 / n, ch = 360 / U_;
    const order = Hd.order ? Hd.order.slice(0, U_) : [...Array(U_).keys()];
    for (let r = 0; r < U_; r++) for (let i = 0; i < n; i++) {
      const v = Hd.get(order[r], i);
      g.fillStyle = v >= 0 ? `rgba(194,106,0,${Math.min(1, v * 1.1).toFixed(3)})` : `rgba(40,44,60,${Math.min(1, -v * 0.9).toFixed(3)})`;
      g.fillRect(i * cw, r * ch, cw + 0.5, ch + 0.5);
    }
    const units = Hd.interp || [];
    $(el, '.hd-units').innerHTML = units.map((u, i) => `<button class="btn" data-i="${i}">unit ${u.unit}: ${esc(u.desc)} <span class="muted">r = ${u.r.toFixed(2)}</span></button>`).join('');
    S.show = (i) => {
      $$(el, '.hd-units .btn').forEach((b) => b.classList.toggle('on', +b.dataset.i === i));
      const u = units[i];
      const cut = Hd.text.lastIndexOf('\n\n', 200);
      $(el, '.hd-text').innerHTML = [...Hd.text.slice(0, cut > 60 ? cut : Hd.text.length)].map((c, j) => {
        const v = u ? Hd.get(u.unit, j) : 0;
        const bg = v >= 0 ? `rgba(194,106,0,${(v * 0.85).toFixed(2)})` : `rgba(37,99,235,${(-v * 0.55).toFixed(2)})`;
        return `<span style="background:${bg}">${c === '\n' ? '↵\n' : esc(c)}</span>`;
      }).join('');
    };
    $$(el, '.hd-units .btn').forEach((b) => (b.onclick = () => S.show(+b.dataset.i)));
    S.show(0);
  },
  step(el, k, S) { if (S.show) S.show(Math.max(0, Math.min(k - 1, (LM.hidden.interp || []).length - 1))); },
  says: [
    'Here is the memory of the trained model reading a passage it never saw: 64 of its 256 memory numbers, one row each. Most rows are a tangled, distributed code. Below, the text is tinted by a single unit: amber where it is positive, blue where negative.',
    'This unit tracks how far along the line the model is: negative at the start of a line, rising toward the end. Across the whole test set its correlation with line position is 0.74. That helps predict when a line break is due.',
    'This one switches off while the model is reading a speaker’s name, like BIANCA, and back on for the speech. Nobody programmed either unit. They emerged from minimising surprise — though a correlation is a hint, not proof of meaning.',
  ],
});

// ───────────────────────────── 23. Why memory fades
slide({
  part: 'Part 4 · Why memory fades', title: 'The repeated product', holds: [0, 1200, 1200, 1200],
  html: `
  <h1>Why memory fades: the same multiplication, over and over</h1>
  <div class="row" style="align-items:center;margin-top:0">
    <div class="col">
      <div class="eq" style="font-size:32px"><span class="h">h<sub>t</sub></span> = <span class="w">W<sub>h</sub></span>·<span class="h">h<sub>t−1</sub></span> &nbsp;⇒&nbsp; <span class="h">h<sub>t</sub></span> = <span class="w">W<sub>h</sub></span><sup>t</sup> · <span class="h">h<sub>0</sub></span></div>
    </div>
    <div class="assume" style="flex:none;width:560px"><p>Stripped-down toy: <b>one number, no inputs, no tanh</b>. It isolates what happens to one piece of information as it is carried forward.</p></div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 360px;gap:30px;margin-top:10px">
    <div class="vf-chart"></div>
    <div class="stack">
      <div class="slider" style="grid-template-columns:50px 1fr 60px"><span class="lab w">W<sub>h</sub></span><input type="range" min="0.5" max="1.5" step="0.05" class="vf-w"><span class="val vf-wv"></span></div>
      <div class="card vf-read" style="font-size:20px;line-height:1.6;padding:12px 18px"></div>
      <div class="assume" data-step="3"><p style="font-size:18px!important">Real RNNs: vectors + tanh. tanh’s slope is <b>never above 1</b>, so it only adds shrinking.</p></div>
    </div>
  </div>`,
  init(el, S) {
    S.render = (w) => {
      S.w = w;
      $(el, '.vf-w').value = w; $(el, '.vf-wv').textContent = w.toFixed(2);
      const K = 40, Wd = 1000, Hh = 400, L = 70, B = 40, T = 10, ch = Hh - T - B;
      const Y = (v) => T + (1 - (Math.log10(Math.max(1e-6, Math.min(1e6, v))) + 6) / 12) * ch;
      let s = `<svg width="${Wd}" height="${Hh}"><rect x="${L}" y="${T}" width="${Wd - L - 10}" height="${ch}" fill="#fff" stroke="var(--rule)"/>`;
      [-6, -4, -2, 0, 2, 4, 6].forEach((e) => (s += `<line x1="${L}" x2="${Wd - 10}" y1="${Y(10 ** e)}" y2="${Y(10 ** e)}" stroke="${e === 0 ? '#9A9FAE' : '#EFEAE0'}"/><text x="${L - 8}" y="${Y(10 ** e) + 5}" text-anchor="end" font-size="14" fill="#8A8F9E">${e === 0 ? '1' : '10' + (e < 0 ? '⁻' : '') + '⁰¹²³⁴⁵⁶'[Math.abs(e)]}</text>`));
      const bw = (Wd - L - 20) / (K + 1);
      for (let k = 0; k <= K; k++) {
        const v = w ** k, y1 = Y(1), y2 = Y(v), x = L + 5 + k * bw;
        s += `<rect x="${x}" y="${Math.min(y1, y2)}" width="${bw - 3}" height="${Math.max(1.5, Math.abs(y2 - y1))}" fill="${v > 1.0001 ? 'var(--y)' : v < 0.9999 ? '#6E86B8' : 'var(--h)'}" rx="2"/>`;
        if (k % 10 === 0) s += `<text x="${x + bw / 2}" y="${Hh - 16}" text-anchor="middle" font-size="14" fill="#8A8F9E">${k}</text>`;
      }
      s += `<text x="${(Wd + L) / 2}" y="${Hh - 0}" text-anchor="middle" font-size="15" fill="#8A8F9E">steps later (t)</text><text x="18" y="${T + ch / 2}" text-anchor="middle" font-size="15" fill="#8A8F9E" transform="rotate(-90 18 ${T + ch / 2})">surviving fraction W_h^t (log scale)</text></svg>`;
      $(el, '.vf-chart').innerHTML = s;
      const f = (v) => (v >= 100 ? Math.round(v).toLocaleString() : v >= 0.01 ? v.toFixed(3) : v.toExponential(1));
      $(el, '.vf-read').innerHTML = `<span class="mono">${w.toFixed(2)}<sup>10</sup> = <b>${f(w ** 10)}</b></span><br><span class="mono">${w.toFixed(2)}<sup>40</sup> = <b>${f(w ** 40)}</b></span><br><span class="${w < 0.999 ? 'muted' : w > 1.001 ? 'y' : 'h'}">${w < 0.999 ? 'vanishing: the past fades to nothing' : w > 1.001 ? 'exploding: the past drowns out everything' : 'exactly 1: a knife edge'}</span>`;
    };
    $(el, '.vf-w').oninput = (e) => S.render(+e.target.value);
  },
  step(el, k, S) {
    const target = [0.7, 0.7, 1.3, 1.0][k], from = S.w ?? 0.7;
    if (k === 0) return S.render(0.7);
    for (let i = 0; i <= 15; i++) S.T.later(() => S.render(from + ((target - from) * i) / 15), i * 60);
  },
  says: [
    'Why does memory fade? Strip the RNN to its skeleton: one number, no inputs, no squash. Each step multiplies the memory by W h. After t steps, whatever was stored at the start has been multiplied by W h, t times.',
    'With W h equal to 0.7, after ten steps only 2.8 percent survives. After forty, essentially nothing. This is the vanishing problem. The bars show the surviving fraction, on a log scale.',
    'With W h equal to 1.3, ten steps amplify it fourteen-fold, forty steps by thirty-six thousand. Exploding.',
    'Only exactly one is stable, and that is a knife edge training can’t sit on. Real RNNs use vectors and tanh, but tanh’s slope is at most one, so it only adds shrinking.',
  ],
});

// ───────────────────────────── 24. Gradients: learning suffers the same product
slide({
  part: 'Part 4 · Why memory fades', title: 'Vanishing gradients',
  html: `
  <h1>Learning suffers the same product: vanishing gradients</h1>
  <div class="row" style="margin-top:4px">
    <div class="col stack">
      <p>To learn that “<b>it</b>” depends on “<b>elephant</b>”, the error at “it” must flow <b>backward</b> to “elephant” — through every step in between.</p>
      <div data-step="1" class="stack">
        <p>Chain rule, in our toy: how much does <span class="h">h<sub>t</sub></span> change if <span class="h">h<sub>t−k</sub></span> changes?</p>
        <div class="eq" style="font-size:34px"><span style="display:inline-flex;flex-direction:column;vertical-align:middle;text-align:center"><span style="border-bottom:2px solid var(--ink);padding:0 6px">∂<span class="h">h<sub>t</sub></span></span><span>∂<span class="h">h<sub>t−k</sub></span></span></span> = <span class="w">W<sub>h</sub></span> × <span class="w">W<sub>h</sub></span> × ⋯ × <span class="w">W<sub>h</sub></span> = <span class="w">W<sub>h</sub></span><sup>k</sup></div>
        <p class="small">The learning signal from k steps back is scaled by the same product. Tiny signal → the weights barely learn from long-range patterns.</p>
      </div>
    </div>
    <div class="col stack" data-step="2">
      <h3>Measured in our trained Shakespeare RNN</h3>
      <div class="gd-chart"></div>
      <p class="small gd-note"></p>
    </div>
  </div>`,
  init(el) {
    if (!window.LM || !LM.grad) return need(el, 'data/gradients.js');
    const G = LM.grad, K = G.ks[G.ks.length - 1];
    const lg = (v) => Math.log10(Math.max(1e-14, v));
    const all = [...G.trained, ...(G.init || [])].filter((v) => v > 0).map(lg);
    const ymin = Math.floor(Math.min(...all)), ymax = Math.max(0, Math.ceil(Math.max(...all)));
    const series = [{ pts: G.ks.map((k, i) => [k, lg(G.trained[i])]), color: 'var(--h)', label: 'trained' }];
    if (G.init) series.push({ pts: G.ks.map((k, i) => [k, lg(G.init[i])]), color: 'var(--muted)', dash: '5 5', width: 2, label: 'random init' });
    const ticks = []; for (let e = ymax; e >= ymin; e -= (ymax - ymin > 8 ? 2 : 1)) ticks.push(e);
    $(el, '.gd-chart').innerHTML = lineSVG({ w: 620, h: 360, xmax: K, ymin, ymax, series, xlab: 'k = characters back', ylab: 'gradient size, log₁₀ (relative to k = 0)', ticksY: ticks });
    const at = (k) => G.trained[G.ks.indexOf(k)];
    $(el, '.gd-note').innerHTML = `Relative to the current step: <b>${U.fmt(at(10), 3)}</b> at 10 characters back, <b>${U.fmt(at(Math.min(20, K)), 3)}</b> at 20, <b>${U.fmt(at(K), 3)}</b> at ${K}. ${G.note ? esc(G.note) : ''}`;
  },
  says: [
    'This isn’t only about remembering; it is about learning. To learn that “it” depends on “elephant”, the error measured at “it” has to flow backward to “elephant”, through every step in between.',
    'That is the chain rule. In our toy, the sensitivity of h t to h t minus k is W h to the power k — the same product. If it vanishes, the learning signal from far away vanishes too; if it explodes, training blows up.',
    'And this is real. We measured the gradient in the trained Shakespeare model, averaged over many passages. The signal from a few dozen characters back is a small fraction of the signal from the current step. Long-range patterns barely get learned.',
  ],
});

// ───────────────────────────── 25. A long-range dependency
slide({
  part: 'Part 4 · Why memory fades', title: 'Long-range dependencies',
  html: `
  <h1>Language is full of long-range dependencies</h1>
  <p class="lede lr-s" style="font-size:36px!important;line-height:1.6!important;margin-top:30px"></p>
  <div class="keyidea" data-step="2" style="margin-top:36px"><p>The clue is <b class="lr-d"></b> characters back. A vanilla RNN has to carry “France” through that many multiplications — and learn to, through that many multiplications of the gradient. It usually can’t.</p></div>`,
  step(el, k) {
    const s = 'I grew up in France, and spent every summer there until I was twelve. Then we moved to Ohio, where I went to school, played in a band and learned to drive. So I speak fluent';
    const words = s.split(' ');
    let pos = 0;
    const tail = s.length;
    $(el, '.lr-d').textContent = s.length - s.indexOf('France');
    $(el, '.lr-s').innerHTML = words.map((w) => {
      const d = tail - pos; pos += w.length + 1;
      const key = w.startsWith('France');
      const fade = k >= 1 ? Math.max(0.1, Math.pow(0.985, d)) : 1;
      return `<span style="opacity:${key ? Math.max(fade, 0.25) : fade};${key ? 'color:var(--x);font-weight:600' : ''}">${esc(w)}</span>`;
    }).join(' ') + ` <span style="display:inline-block;width:130px;border-bottom:3px solid var(--y)"></span>`;
  },
  says: [
    'Language is full of long-range dependencies. What goes in the blank? You know instantly: French. The clue is way back at the start.',
    'But for a vanilla RNN the clue has faded by the time it matters — shown here as the text dimming with distance. This fading is only illustrative, but the effect is the one we just measured.',
    'To carry “France” to the blank, the memory must survive over 150 multiplications, and so must the learning signal. In practice, vanilla RNNs struggle with this. Two fixes changed history.',
  ],
});

// ───────────────────────────── 26. LSTM
slide({
  part: 'Part 4 · Why memory fades', title: 'Fix #1: LSTM',
  html: `
  <h1>Fix #1 (1997): the LSTM’s conveyor belt</h1>
  <div class="row" style="margin-top:0;align-items:flex-start">
    <div style="flex:none;width:860px">
      <svg width="860" height="370" viewBox="0 0 860 370">
        <defs><marker id="ar3" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0L10,5L0,10z" fill="#9A9FAE"/></marker>
          <marker id="ar4" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0,0L10,5L0,10z" fill="var(--h)"/></marker></defs>
        <rect x="120" y="40" width="620" height="290" rx="22" fill="#fff" stroke="var(--rule)" stroke-width="2"/>
        <line x1="20" y1="90" x2="840" y2="90" stroke="var(--h)" stroke-width="9" marker-end="url(#ar4)" opacity=".85"/>
        <text x="24" y="70" font-size="20" fill="var(--h)" font-family="Newsreader">c<tspan font-size="14" dy="4">t−1</tspan></text>
        <text x="800" y="70" font-size="20" fill="var(--h)" font-family="Newsreader">c<tspan font-size="14" dy="4">t</tspan></text>
        <text x="430" y="30" text-anchor="middle" font-size="16" fill="var(--h)" letter-spacing="2">CELL STATE: THE CONVEYOR BELT</text>
        <g data-step="1"><circle cx="270" cy="90" r="24" fill="#fff" stroke="var(--ink)" stroke-width="2.5"/><text x="270" y="99" text-anchor="middle" font-size="26">×</text>
          <line x1="270" y1="222" x2="270" y2="118" stroke="#9A9FAE" stroke-width="2" marker-end="url(#ar3)"/>
          <rect x="215" y="222" width="110" height="46" rx="10" fill="var(--a-bg)" stroke="var(--a)"/><text x="270" y="252" text-anchor="middle" font-size="18" fill="var(--a)">forget f</text></g>
        <g data-step="1"><circle cx="470" cy="90" r="24" fill="#fff" stroke="var(--ink)" stroke-width="2.5"/><text x="470" y="99" text-anchor="middle" font-size="26">+</text>
          <line x1="470" y1="222" x2="470" y2="118" stroke="#9A9FAE" stroke-width="2" marker-end="url(#ar3)"/>
          <rect x="395" y="222" width="150" height="46" rx="10" fill="var(--a-bg)" stroke="var(--a)"/><text x="470" y="252" text-anchor="middle" font-size="18" fill="var(--a)">write i × new g</text></g>
        <g data-step="1"><line x1="650" y1="96" x2="650" y2="220" stroke="#9A9FAE" stroke-width="2" marker-end="url(#ar3)"/>
          <rect x="590" y="222" width="120" height="46" rx="10" fill="var(--a-bg)" stroke="var(--a)"/><text x="650" y="252" text-anchor="middle" font-size="18" fill="var(--a)">read o</text>
          <line x1="710" y1="245" x2="840" y2="245" stroke="var(--h)" stroke-width="3" marker-end="url(#ar3)"/><text x="800" y="235" font-size="20" fill="var(--h)" font-family="Newsreader">h<tspan font-size="14" dy="4">t</tspan></text></g>
        <text x="130" y="318" font-size="16" fill="#8A8F9E" data-step="1">each gate: numbers between 0 and 1, computed from x<tspan font-size="11" dy="3">t</tspan><tspan dy="-3"> and h</tspan><tspan font-size="11" dy="3">t−1</tspan></text>
      </svg>
      <div class="eq" data-step="2" style="font-size:31px;margin-top:4px"><span class="h">c<sub>t</sub></span> = <span class="a">f</span> × <span class="h">c<sub>t−1</sub></span> <b>+</b> <span class="a">i</span> × g &nbsp;&nbsp;&nbsp; <span class="h">h<sub>t</sub></span> = <span class="a">o</span> × tanh(<span class="h">c<sub>t</sub></span>)</div>
    </div>
    <div class="col stack">
      <div data-step="2" class="ls-chart"></div>
      <div class="keyidea" data-step="3"><p>Q: What do LSTMs and elephants have in common? 🐘<br>A: Excellent memories. And the <span class="mono">tiny_rnn.py</span> in Workshop 4 uses an LSTM.</p></div>
    </div>
  </div>`,
  init(el) {
    const a = [], b = [];
    for (let k = 0; k <= 60; k++) { a.push([k, 0.7 ** k]); b.push([k, 0.98 ** k]); }
    $(el, '.ls-chart').innerHTML = `<h3>What survives k steps</h3>` + lineSVG({ w: 520, h: 280, xmax: 60, ymin: 0, ymax: 1.05, series: [{ pts: a, color: '#6E86B8', label: 'vanilla, W_h = 0.7' }, { pts: b, color: 'var(--h)', label: 'LSTM belt, forget f = 0.98' }], xlab: 'steps later (k)', ylab: 'fraction kept', ticksY: [0, 0.5, 1] });
  },
  says: [
    'Fix number one, from 1997: the Long Short-Term Memory, or LSTM. It adds a second memory line — think of a conveyor belt — that runs straight through time.',
    'Three gates control it. Each gate is a set of numbers between zero and one, computed from the current input and previous output. Forget: how much of the belt to keep. Write: how much new information to add. Read: how much of the belt to show as this step’s output.',
    'The key move is on the belt: memory is kept by multiplying by the forget gate, which the model can learn to hold near one, and new information is added, not pushed through a squash every step. Information, and gradient, can ride the belt for hundreds of steps.',
    'What do LSTMs and elephants have in common? Excellent memories. And the tiny RNN in your workshop code is actually an LSTM.',
  ],
});

// ───────────────────────────── 27. Fix #2 preview: attention
slide({
  part: 'Part 4 · Why memory fades', title: 'Fix #2: look back directly',
  html: `
  <div class="center" style="padding-top:40px">
    <h3>Fix #2 · preview</h3>
    <h1 style="font-size:64px">What if, instead of remembering,<br>you could simply <i class="h">look back</i>?</h1>
    <svg class="at-svg" width="1400" height="320" style="margin-top:4px"></svg>
    <p class="lede" data-step="1" style="font-size:28px!important">That’s <b>attention</b> (2017): every token can look directly at every earlier token and decide which ones matter. No fading. It is the engine of the Transformer, and of every modern LLM. <span class="muted">That’s next week, Week 5: Transformers.</span></p>
  </div>`,
  init(el) {
    const W = 'The pink elephant tried to get into the car but it was too'.split(' ');
    const wts = [0.02, 0.07, 0.46, 0.04, 0.01, 0.03, 0.03, 0.02, 0.2, 0.04];
    const cw = 1400 / W.length, y = 290;
    let s = W.map((w, i) => `<text x="${cw * i + cw / 2}" y="${y + 10}" text-anchor="middle" font-size="30" font-family="Newsreader" fill="${i === 10 ? 'var(--x)' : w === 'elephant' || w === 'pink' ? 'var(--y)' : 'var(--ink)'}">${w}</text>`).join('');
    wts.forEach((p, j) => {
      const x0 = cw * 10 + cw / 2, x1 = cw * j + cw / 2, h = 24 + 0.19 * (x0 - x1);
      s += `<path d="M${x0},${y - 26} Q${(x0 + x1) / 2},${y - 26 - 2 * h} ${x1},${y - 26}" fill="none" stroke="${j === 2 ? 'var(--y)' : 'var(--x)'}" stroke-width="${1 + p * 20}" opacity="${0.25 + p * 1.5}"/>`;
    });
    $(el, '.at-svg').innerHTML = s;
  },
  says: [
    'The second fix changed everything. What if, instead of carrying a fading memory forward, each word could simply look back at every earlier word?',
    'That is attention, from 2017: every token looks directly at every earlier token and decides which ones matter. No chain of multiplications, so nothing fades. It is the engine of the Transformer, and of every modern large language model. That is next week.',
  ],
});

// ───────────────────────────── 28. Recap: the whole pipeline
slide({
  part: 'Part 5 · Recap', title: 'The whole machine',
  html: `
  <h1>The whole machine, on one screen</h1>
  <div style="display:flex;align-items:stretch;gap:10px;margin-top:30px">
    ${[
      ['text', 'ROMEO: But', 'var(--ink)', '#fff', 'Part 0'],
      ['tokens', 'R O M E O : ␣ B u t', 'var(--x)', 'var(--x-bg)', 'Part 1'],
      ['one-hot x<sub>t</sub>', '[0 … 1 … 0]', 'var(--x)', 'var(--x-bg)', 'Part 1'],
      ['memory', 'h<sub>t</sub> = tanh(W<sub>x</sub>x<sub>t</sub> + W<sub>h</sub>h<sub>t−1</sub> + b)', 'var(--h)', 'var(--h-bg)', 'Part 3'],
      ['scores', 'W<sub>y</sub>h<sub>t</sub> + c', 'var(--w)', 'var(--w-bg)', 'Part 3'],
      ['probabilities', 'softmax(scores ÷ T)', 'var(--y)', 'var(--y-bg)', 'Part 3'],
      ['sample', 'throw the dart', 'var(--y)', 'var(--y-bg)', 'Part 2'],
    ].map(([a, b, c, bg, p], i) => `<div data-step="${i < 4 ? 0 : 1}" style="flex:1;background:${bg};border:2px solid ${c};border-radius:14px;padding:14px 12px;text-align:center"><div style="font-size:13px;letter-spacing:.14em;text-transform:uppercase;color:${c};font-weight:600">${a}</div><div style="font-family:var(--serif);font-size:21px;margin-top:8px;color:var(--ink)">${b}</div><div class="small muted" style="margin-top:8px">${p}</div></div>${i < 6 ? '<div style="align-self:center;color:var(--muted);font-size:26px">→</div>' : ''}`).join('')}
  </div>
  <div data-step="2" style="text-align:center;margin-top:6px"><svg width="1420" height="80"><path d="M1340,4 C1340,70 1340,70 700,70 C80,70 80,70 80,6" fill="none" stroke="var(--y)" stroke-width="3" stroke-dasharray="7 6"/><text x="710" y="60" text-anchor="middle" font-size="18" fill="var(--y)">append the sampled character, and repeat</text></svg></div>
  <div class="row" data-step="3" style="margin-top:10px">
    <div class="col card"><h3>Training</h3><p class="small">Every position of the text is a quiz. Loss = average surprise, −log p(correct). Gradient descent tunes W<sub>x</sub>, W<sub>h</sub>, W<sub>y</sub>, b, c.</p></div>
    <div class="col card"><h3>Generation</h3><p class="small">Run the loop: memory → probabilities → sample → append. Temperature trades safety for surprise.</p></div>
    <div class="col card"><h3>The weak spot</h3><p class="small">Memory is carried by repeated multiplication, so it fades (or explodes), and so does the learning signal.</p></div>
  </div>`,
  says: [
    'Here is the whole machine. Text becomes tokens, tokens become one-hot vectors, and each one updates a fixed-size memory.',
    'The memory becomes one score per character, softmax turns scores into probabilities, and we sample.',
    'Append the sampled character and go around again. That loop is generation.',
    'Training fills in the weights by minimising surprise at every position. And the weak spot is the memory itself: carried by repeated multiplication, it fades.',
  ],
});

// ───────────────────────────── 29. Assumptions ledger
slide({
  part: 'Part 5 · Recap', title: 'Every assumption we made',
  html: `
  <h1>Every assumption we made today</h1>
  <table class="data" style="margin-top:14px;font-size:21px">
    <tr><th style="width:33%">We assumed…</th><th style="width:37%">Where it breaks</th><th>What fixes it</th></tr>
    <tr><td>Text is a sequence of tokens from a <b>fixed vocabulary</b></td><td>Characters make sequences long; whole words can’t handle new words</td><td>Subword tokenizers</td></tr>
    <tr><td>Each token is a <b>one-hot</b> vector: all equally different</td><td>“cat” is as far from “dog” as from “carburetor”</td><td>Learned embeddings (Week 5, Transformers)</td></tr>
    <tr><td>The next token depends only on the <b>current</b> one (Markov)</td><td>Can’t link “it” to “elephant”; bigger tables explode</td><td>A recurrent memory h</td></tr>
    <tr><td>Memory is a <b>fixed-size</b> vector, updated by the <b>same rule</b> every step</td><td>Information and gradients fade (or explode) with distance</td><td>LSTM gates; then attention (Week 5)</td></tr>
    <tr><td>The model only sees the <b>past</b></td><td>Fine for writing; wasteful for understanding a finished text</td><td>Bidirectional / encoder models (later)</td></tr>
    <tr><td>Output is a distribution and we <b>sample</b> from it</td><td>Greedy loops; too random gives gibberish</td><td>Temperature (and other decoding tricks)</td></tr>
  </table>`,
  says: [
    'Here is every assumption we made today, where each one breaks, and what fixes it. Most of the rest of the language-model part of this course is the right-hand column.',
  ],
});

// ───────────────────────────── 30. Workshop 4 bridge
const TINY = `text = "\\n".join(tiny_lines)                    # 1  corpus
chars = sorted(list(set(text)))                 #    vocabulary = characters
stoi = {c:i for i,c in enumerate(chars)}        #    char -> ID
seq_len = 40
for i in range(0, len(text) - seq_len):         # 2  every position is a quiz
    X_idx.append([stoi[c] for c in text[i:i+seq_len]])
    y_idx.append(stoi[text[i+seq_len]])         #    ...answer = next char
model = tf.keras.Sequential([
    tf.keras.layers.Embedding(vocab_size, 32),  # 3  learned vectors (Week 5)
    tf.keras.layers.LSTM(128),                  #    memory: 128 numbers, gated
    tf.keras.layers.Dense(vocab_size)])         #    scores  = W_y h + c
model.compile(optimizer=Adam(1e-2),             # 4  gradient descent
    loss=SparseCategoricalCrossentropy(from_logits=True))  # softmax + surprise
model.fit(X, y, batch_size=64, epochs=20)
def sample_logits(logits, temperature=1.0):     # 5  generation
    logits = logits / temperature               #    temperature
    p = tf.nn.softmax(logits).numpy()           #    probabilities
    return int(np.random.choice(len(p), p=p))   #    throw the dart`;
slide({
  part: 'Part 5 · Recap', title: 'Workshop 4: tiny_rnn.py',
  html: `
  <h1>You can now read every line of Workshop 4</h1>
  <div class="row" style="margin-top:4px">
    <div style="flex:none;width:950px" class="wk-code"></div>
    <div class="col stack">
      <div class="card wk-note" style="font-size:21px;line-height:1.5"></div>
      <div class="assume" data-step="5"><p>One honest difference: <span class="mono">tiny_rnn.py</span> reads a fresh 40-character window every time, starting its memory from zero. Its memory can never reach further back than 40 characters.</p></div>
    </div>
  </div>`,
  init(el) { $(el, '.wk-code').innerHTML = U.code(TINY).replace('class="code"', 'class="code" style="font-size:15px"'); },
  step(el, k) {
    const hl = [[1, 2, 3], [4, 5, 6, 7], [8, 9, 10, 11], [12, 13, 14], [15, 16, 17, 18], [5, 6]][k];
    U.hlLines($(el, 'pre'), hl);
    $(el, '.wk-note').innerHTML = [
      '<b>1 · Text → numbers.</b> A character vocabulary and a lookup from character to ID: Part 1.',
      '<b>2 · The quizzes.</b> Slide a 40-character window; the answer is the character right after it: “every position is a quiz”.',
      '<b>3 · The model.</b> Embedding = a learned version of W<sub>x</sub>·one-hot. LSTM(128) = gated memory with 128 numbers. Dense = the readout W<sub>y</sub>h + c, giving one score per character.',
      '<b>4 · Training.</b> “from_logits=True” means: apply softmax, then score the surprise. Adam is a flavour of gradient descent.',
      '<b>5 · Generation.</b> Divide by temperature, softmax, throw the dart. Exactly our loop.',
      '<b>Window, not stream.</b> Each quiz starts from an empty memory, so context is capped at 40 characters.',
    ][k];
  },
  says: [
    'You can now read every line of the Workshop 4 code. Block one: the corpus, a character vocabulary, and a lookup from character to ID. That is Part 1.',
    'Block two builds the quizzes: slide a 40-character window, and the answer is the character right after it.',
    'Block three is the model. The embedding layer is a learned version of W x times one-hot. The LSTM is gated memory with 128 numbers. The dense layer is the readout: one score per character.',
    'Block four trains it. “From logits” means: apply softmax, then score the surprise. Adam is a flavour of gradient descent.',
    'Block five generates: divide by temperature, softmax, throw the dart. Our loop.',
    'One honest difference from today’s picture: this code gives the model a fresh 40-character window each time, starting from empty memory. Its context can never reach further back than that.',
  ],
});

// ───────────────────────────── 31. Check yourself
const QS = [
  ['A bigram table over 27 characters holds how many numbers? A trigram table (two characters of context)?', '27 × 27 = 729.  27³ = 19,683 (27² contexts × 27 next characters).'],
  ['Using the a/b/c table, why does greedy decoding from “a” get stuck?', 'The top choice after a is b (0.6), and the top choice after b is b again (0.6): b forever.'],
  ['Toy RNN, no input: W_h = 0.9, h₀ = 1. Roughly what is h after 20 steps?', '0.9²⁰ ≈ 0.12: about 12% survives.'],
  ['Scores [2, 0] for two characters. Softmax probabilities?', 'e² / (e² + e⁰) = 7.39 / 8.39 ≈ 0.88, and 0.12.'],
  ['What happens to the probabilities as temperature T → 0?', 'All probability goes to the top-scoring token: greedy decoding.'],
  ['How can one RNN, with a fixed number of weights, read text of any length?', 'Weight sharing: the same cell and weights are reused at every step; only the memory changes.'],
];
slide({
  part: 'Part 5 · Recap', title: 'Check yourself',
  html: `
  <h1>Check yourself <span class="small muted" style="font-family:var(--sans)">(click a question to reveal)</span></h1>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px 30px;margin-top:10px">
    ${QS.map(([q, a], i) => `<div class="card reveal-q" data-q="${i}" style="padding:16px 20px"><p style="font-size:21px;color:var(--ink)"><b>${i + 1}.</b> ${esc(q)}</p><p class="ans" style="font-size:20px;margin-top:8px">${esc(a)}</p></div>`).join('')}
  </div>`,
  init(el) { $$(el, '.reveal-q').forEach((q) => (q.onclick = () => q.classList.toggle('open'))); },
  step(el, k) { $$(el, '.reveal-q').forEach((q, i) => q.classList.toggle('open', k >= 1 && i < (k === 1 ? 6 : 0))); },
  says: [
    'Six questions to check yourself. Pause here and answer them on paper before revealing.',
    'Here are the answers. If any surprised you, go back to the part it came from.',
  ],
});

// ───────────────────────────── 32. End
slide({
  part: 'Week 4', title: '',
  html: `
  <div class="center" style="padding-top:170px">
    <h1 style="font-size:84px">Guess what comes next.</h1>
    <p class="lede" style="margin-top:20px">Up next, Week 5: <b>Transformers</b>. Embeddings give tokens meaning, and attention lets the model stop forgetting.</p>
    <p class="small muted" style="margin-top:60px">CPSC 1710 · Week 4 · the RNN on these slides is a real model, trained on the complete works of Shakespeare, running in your browser.</p>
  </div>`,
  says: ['That is the whole game: guess what comes next. Next week, Week 5: Transformers — embeddings that give tokens meaning, and attention, the model that stopped forgetting.'],
});
})();
