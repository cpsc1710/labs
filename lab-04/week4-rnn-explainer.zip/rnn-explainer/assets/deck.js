/* Deck engine: 1600×900 stage, slides with narrated steps.
   slide({part, title, html, says:[...], init(el,S), enter(el,S), step(el,k,S,prev), leave(el,S)})
   Elements with data-step="n" appear from step n; "n-m" only for steps n..m; data-dim="n" dims from step n. */
(function () {
  const SL = (window.SLIDES = []);
  window.slide = (def) => SL.push(def);

  // ---------------- helpers shared by slides ----------------
  const U = (window.U = {});
  U.$ = (r, s) => r.querySelector(s);
  U.$$ = (r, s) => Array.from(r.querySelectorAll(s));
  U.mulberry32 = (a) => () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  U.pick = (probs, r) => {
    let acc = 0;
    for (let i = 0; i < probs.length; i++) { acc += probs[i]; if (r < acc) return i; }
    return probs.length - 1;
  };
  U.softmax = (z, T = 1) => {
    const m = Math.max(...z.map((v) => v / T));
    const e = z.map((v) => Math.exp(v / T - m));
    const s = e.reduce((a, b) => a + b, 0);
    return e.map((v) => v / s);
  };
  U.fmt = (v, d = 2) => (Math.abs(v) >= 1e4 || (Math.abs(v) < 1e-3 && v !== 0) ? v.toExponential(1) : v.toFixed(d));
  U.esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  U.showChar = (c) => (c === ' ' ? '␣' : c === '\n' ? '↵' : c);
  U.bars = (items, opt = {}) =>
    `<div class="bars">${items.map((it) => `<div class="b"><div class="lab">${U.esc(it.lab)}</div><div class="track"><div class="fill" style="width:${(it.p * 100 * (opt.scale || 1)).toFixed(1)}%;background:${it.color || 'var(--y)'}"></div></div><div class="num">${it.num ?? (it.p * 100).toFixed(0) + '%'}</div></div>`).join('')}</div>`;
  U.sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  U.code = (src) =>
    `<pre class="code">${src.split('\n').map((l) => {
      let s = U.esc(l);
      s = s.replace(/(#.*)$/, '<span class="cm">$1</span>');
      s = s.replace(/\b(for|in|def|return|import|as|while|if|not|raise)\b(?![^<]*<\/span>)/g, '<span class="kw">$1</span>');
      return `<span class="ln">${s || ' '}</span>`;
    }).join('')}</pre>`;
  U.hlLines = (pre, lines) => U.$$(pre, '.ln').forEach((ln, i) => ln.classList.toggle('hl', lines.includes(i + 1)));

  // per-slide timers, cleared on step change / leave
  function timerBag() {
    const ids = new Set();
    return {
      later(fn, ms) { const id = setTimeout(() => { ids.delete(id); fn(); }, ms); ids.add(id); return id; },
      every(fn, ms) { const id = setInterval(fn, ms); ids.add(id); return id; },
      clear() { ids.forEach((id) => { clearTimeout(id); clearInterval(id); }); ids.clear(); },
    };
  }

  // ---------------- engine ----------------
  let stage, cap, capT, cur = -1, step = 0;
  const params = new URLSearchParams(location.search);

  function fit() {
    const s = Math.min(innerWidth / 1600, innerHeight / 900);
    stage.style.transform = `scale(${s})`;
  }

  function build(i) {
    const def = SL[i];
    if (def.el) return def;
    const el = document.createElement('section');
    el.className = 'slide';
    el.innerHTML = def.html;
    stage.appendChild(el);
    def.el = el;
    def.T = timerBag();
    if (def.init) def.init(el, def);
    return def;
  }

  function applySteps(el, k) {
    U.$$(el, '[data-step]').forEach((n) => {
      const [a, b] = n.dataset.step.split('-').map(Number);
      const vis = k >= a && (isNaN(b) || k <= b);
      n.classList.toggle('hidden-step', !vis);
    });
    U.$$(el, '[data-dim]').forEach((n) => n.classList.toggle('dim-step', k >= Number(n.dataset.dim)));
  }

  function sayText(def, k) {
    const s = def.says[k];
    return typeof s === 'function' ? s(def) : s;
  }

  function go(i, k) {
    i = Math.max(0, Math.min(SL.length - 1, i));
    const def = build(i);
    k = Math.max(0, Math.min(def.says.length - 1, k));
    const prevK = i === cur ? step : -1;
    if (i !== cur) {
      if (cur >= 0) {
        const old = SL[cur];
        old.T.clear();
        old.el.classList.remove('active');
        if (old.leave) old.leave(old.el, old);
      }
      def.el.classList.add('active');
      cur = i;
      if (def.enter) def.enter(def.el, def);
    }
    def.T.clear();
    step = k;
    applySteps(def.el, k);
    if (def.step) def.step(def.el, k, def, prevK);
    // chrome
    U.$(stage, '#topbar .part').textContent = def.part || '';
    U.$(stage, '#topbar .ttl').textContent = def.title || '';
    U.$(stage, '#topbar .count').textContent = `${i + 1} / ${SL.length}`;
    U.$(stage, '#progress').style.width = `${((i + (k + 1) / def.says.length) / SL.length) * 100}%`;
    capT.style.opacity = 0;
    const txt = sayText(def, k);
    setTimeout(() => { capT.textContent = txt; capT.style.opacity = 1; }, 180);
    history.replaceState(null, '', `${location.search}#${i + 1}.${k + 1}`);
  }

  function next() {
    const def = SL[cur];
    if (step < def.says.length - 1) go(cur, step + 1);
    else if (cur < SL.length - 1) go(cur + 1, 0);
  }
  function prev() {
    if (step > 0) go(cur, step - 1);
    else if (cur > 0) { const d = build(cur - 1); go(cur - 1, d.says.length - 1); }
  }

  window.deck = {
    go, next, prev,
    state: () => ({ slide: cur, step, nSlides: SL.length, nSteps: SL[cur].says.length, say: sayText(SL[cur], step) }),
    all: () => SL.map((d, i) => ({ i, n: d.says.length })),
    sayOf: (i, k) => sayText(build(i), k),
    holdOf: (i, k) => (build(i).holds || [])[k] || 0,
  };

  window.addEventListener('DOMContentLoaded', () => {
    stage = document.getElementById('stage');
    stage.insertAdjacentHTML('afterbegin', `<div id="progress"></div>
      <div id="topbar"><span class="part"></span><span class="ttl"></span><span class="count"></span></div>
      <div id="caption"><span class="t"></span></div>
      <div id="nav"><button id="bprev" title="Back (←)">‹</button><button id="bnext" title="Next (→ or space)">›</button></div>
      <div id="help">→ next · ← back · N narration · F fullscreen</div>`);
    cap = U.$(stage, '#caption');
    capT = U.$(stage, '#caption .t');
    if (params.has('rec')) document.body.classList.add('recording');
    if (params.get('narration') === 'off') cap.classList.add('off');
    U.$(stage, '#bnext').onclick = next;
    U.$(stage, '#bprev').onclick = prev;
    fit();
    addEventListener('resize', fit);
    addEventListener('keydown', (e) => {
      if (e.target.tagName === 'INPUT' && e.target.type === 'text') return;
      if (['ArrowRight', 'PageDown', ' '].includes(e.key)) { e.preventDefault(); next(); }
      else if (['ArrowLeft', 'PageUp'].includes(e.key)) { e.preventDefault(); prev(); }
      else if (e.key === 'Home') go(0, 0);
      else if (e.key === 'End') go(SL.length - 1, 0);
      else if (e.key === 'n' || e.key === 'N') cap.classList.toggle('off');
      else if (e.key === 'f' || e.key === 'F') {
        if (!document.fullscreenElement) document.documentElement.requestFullscreen(); else document.exitFullscreen();
      }
    });
    const m = location.hash.match(/#(\d+)(?:\.(\d+))?/);
    go(m ? Number(m[1]) - 1 : 0, m && m[2] ? Number(m[2]) - 1 : 0);
  });
})();
