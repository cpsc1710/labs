/* Part 3: memory — the recurrent neural network */
(function () {
const { $, $$, esc, bars, mulberry32, pick, showChar } = U;

/* An unrolled chain diagram. cells: [{x, h, y}] labels (strings, '' hides). */
U.chain = function ({ cells, w = 1400, h0 = 'h₀', showY = false, showW = false, xLab = 'x', hi = -1, hw = 118 }) {
  const n = cells.length, gap = (w - 150) / n, H = showY ? 400 : 300, yH = showY ? 200 : 110, yX = yH + 150, yY = 50;
  let s = `<svg width="${w}" height="${H}" viewBox="0 0 ${w} ${H}"><defs><marker id="ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0L10,5L0,10z" fill="#9A9FAE"/></marker></defs>`;
  const cx = (i) => 150 + gap * i + gap / 2;
  s += `<rect x="20" y="${yH - 32}" width="96" height="64" rx="14" fill="#fff" stroke="var(--h)" stroke-width="2" stroke-dasharray="5 4"/><text x="68" y="${yH + 9}" text-anchor="middle" font-size="24" fill="var(--h)" font-family="Newsreader">${h0}</text>`;
  cells.forEach((c, i) => {
    const x = cx(i), px = i === 0 ? 116 : cx(i - 1) + hw / 2, on = c.h !== '' && c.h != null, act = i === hi;
    s += `<line x1="${px + 4}" y1="${yH}" x2="${x - hw / 2 - 6}" y2="${yH}" stroke="${on ? 'var(--h)' : '#D5CEC0'}" stroke-width="${on ? 4 : 2}" marker-end="url(#ar)"/>`;
    if (showW) s += `<text x="${(px + x - hw / 2) / 2}" y="${yH - 12}" text-anchor="middle" font-size="19" fill="var(--w)" font-family="Newsreader" font-style="italic">W<tspan font-size="13" dy="4">h</tspan></text>`;
    s += `<rect x="${x - hw / 2}" y="${yH - 36}" width="${hw}" height="72" rx="16" fill="${on ? 'var(--h-bg)' : '#fff'}" stroke="${act ? 'var(--y)' : 'var(--h)'}" stroke-width="${act ? 4 : 2}"/>`;
    s += `<text x="${x}" y="${yH + 10}" text-anchor="middle" font-size="27" fill="var(--h)" font-family="JetBrains Mono">${on ? c.h : ''}</text>`;
    s += `<line x1="${x}" y1="${yX - 30}" x2="${x}" y2="${yH + 42}" stroke="#9A9FAE" stroke-width="2" marker-end="url(#ar)"/>`;
    if (showW) s += `<text x="${x + 12}" y="${(yX + yH) / 2 + 12}" font-size="19" fill="var(--w)" font-family="Newsreader" font-style="italic">W<tspan font-size="13" dy="4">x</tspan></text>`;
    s += `<circle cx="${x}" cy="${yX}" r="28" fill="var(--x-bg)" stroke="var(--x)" stroke-width="2"/><text x="${x}" y="${yX + 9}" text-anchor="middle" font-size="25" fill="var(--x)" font-family="JetBrains Mono">${c.x}</text>`;
    s += `<text x="${x}" y="${yX + 58}" text-anchor="middle" font-size="16" fill="#8A8F9E">${xLab}<tspan font-size="12" dy="4">${i + 1}</tspan></text>`;
    if (showY) {
      s += `<line x1="${x}" y1="${yH - 40}" x2="${x}" y2="${yY + 30}" stroke="#9A9FAE" stroke-width="2" marker-end="url(#ar)"/>`;
      if (showW) s += `<text x="${x + 12}" y="${(yH + yY) / 2 + 4}" font-size="19" fill="var(--w)" font-family="Newsreader" font-style="italic">W<tspan font-size="13" dy="4">y</tspan></text>`;
      s += `<rect x="${x - 40}" y="${yY - 26}" width="80" height="52" rx="10" fill="var(--y-bg)" stroke="var(--y)" stroke-width="2"/><text x="${x}" y="${yY + 8}" text-anchor="middle" font-size="23" fill="var(--y)" font-family="JetBrains Mono">${c.y ?? ''}</text>`;
    }
  });
  return s + '</svg>';
};

// ───────────────────────────── 13. A loop with a running summary
const SUM_CODE = `x = [3, 5, 4]     # the input sequence
h = 0             # the running summary
for xt in x:
    h = h + xt    # update the summary
    print(h)`;
slide({
  part: 'Part 3 · Memory', title: 'A loop that carries a summary', holds: [0, 5200, 0],
  html: `
  <h1>Forget tables. Carry a <span class="h">running summary</span> instead.</h1>
  <div class="row" style="margin-top:6px;align-items:center">
    <div style="flex:none;width:520px">${U.code(SUM_CODE)}</div>
    <div class="col"><p class="lede" style="font-size:28px!important">Read one input at a time. After each one, update a single number <b class="h">h</b> that summarises everything so far.</p></div>
  </div>
  <div class="rs-chain" style="margin-top:14px"></div>
  <div class="keyidea" data-step="2"><p><b class="h">h</b> has a <b>fixed size</b> (one number) however long the sequence is. And it is <b>lossy</b>: from 12 you can’t recover 3, 5, 4. That compression is the whole idea of a recurrent neural network. We call <b class="h">h</b> the <b>hidden state</b>.</p></div>`,
  step(el, k, S) {
    const xs = [3, 5, 4], hs = [3, 8, 12];
    const draw = (m, hi) => ($(el, '.rs-chain').innerHTML = U.chain({ w: 1000, cells: xs.map((x, i) => ({ x, h: i < m ? hs[i] : '' })), h0: 'h₀=0', hi }));
    const pre = $(el, 'pre');
    draw(k === 0 ? 0 : 3, -1);
    U.hlLines(pre, k === 0 ? [1, 2] : []);
    if (k === 1) {
      draw(0, -1);
      [0, 1, 2].forEach((i) => {
        S.T.later(() => { draw(i, i); U.hlLines(pre, [3]); }, 300 + i * 1500);
        S.T.later(() => { draw(i + 1, i); U.hlLines(pre, [4]); }, 1000 + i * 1500);
      });
      S.T.later(() => { draw(3, -1); U.hlLines(pre, []); }, 300 + 3 * 1500);
    }
  },
  says: [
    'Forget tables. Here is a different kind of machine: a loop that carries one number — a running summary — through a sequence. In this example, the summary is a running total.',
    'Start at zero. Read 3: the summary is 3. Read 5: it becomes 8. Read 4: 12. The carried number is called the hidden state, h.',
    'Two things to notice. h has a fixed size — one number — no matter how long the sequence. And it is lossy: from 12 you cannot recover 3, 5, 4. That compression is the whole idea of a recurrent neural network.',
  ],
});

// ───────────────────────────── 14. Make it learnable
const EQ_LIN = `<span class="h">h<sub>t</sub></span> <span class="op">=</span> <span class="w">W<sub>x</sub></span>·<span class="x">x<sub>t</sub></span> <span class="op">+</span> <span class="w">W<sub>h</sub></span>·<span class="h">h<sub>t−1</sub></span> <span class="op">+</span> <span class="w">b</span>`;
slide({
  part: 'Part 3 · Memory', title: 'Give the loop knobs',
  html: `
  <h1>Give the loop knobs, and training can choose them</h1>
  <div class="eq" style="margin:4px 0 14px">${EQ_LIN}</div>
  <div class="row">
    <div style="flex:none;width:470px" class="stack">
      <div class="legend">
        <span class="sym h">h<sub>t</sub></span><span class="def">new summary, after reading step <i>t</i></span>
        <span class="sym h">h<sub>t−1</sub></span><span class="def">previous summary (h₀ = 0 to start)</span>
        <span class="sym x">x<sub>t</sub></span><span class="def">the input at step <i>t</i></span>
        <span class="sym w">W<sub>x</sub></span><span class="def">how strongly the <b>new input</b> counts</span>
        <span class="sym w">W<sub>h</sub></span><span class="def">how strongly the <b>old summary</b> counts</span>
        <span class="sym w">b</span><span class="def">a constant nudge (bias)</span>
      </div>
      <div class="card stack" style="padding:14px 18px">
        <div class="slider"><span class="lab w">W<sub>x</sub></span><input type="range" min="-2" max="2" step="0.1" data-k="wx"><span class="val"></span></div>
        <div class="slider"><span class="lab w">W<sub>h</sub></span><input type="range" min="-1.5" max="1.5" step="0.1" data-k="wh"><span class="val"></span></div>
        <div class="slider"><span class="lab w">b</span><input type="range" min="-3" max="3" step="0.5" data-k="b"><span class="val"></span></div>
        <div class="btns"><button class="btn" data-p="sum">running sum</button><button class="btn" data-p="fade">forgetful</button><button class="btn" data-p="deaf">ignores input</button></div>
      </div>
    </div>
    <div class="col">
      <div class="lr-chain"></div>
      <div class="card lr-calc mono" style="font-size:21px;line-height:1.7;margin-top:6px"></div>
    </div>
  </div>`,
  init(el, S) {
    S.v = { wx: 1, wh: 1, b: 0 };
    const P = { sum: { wx: 1, wh: 1, b: 0 }, fade: { wx: 1, wh: 0.5, b: 0 }, deaf: { wx: 0, wh: 1, b: 1 } };
    S.render = () => {
      const { wx, wh, b } = S.v, xs = [3, 5, 4];
      $$(el, 'input[type=range]').forEach((r) => { r.value = S.v[r.dataset.k]; r.nextElementSibling.textContent = S.v[r.dataset.k].toFixed(1); });
      let h = 0; const hs = [], rows = [];
      xs.forEach((x, i) => {
        const nh = wx * x + wh * h + b;
        rows.push(`h<sub>${i + 1}</sub> = <span class="w">${wx.toFixed(1)}</span>·<span class="x">${x}</span> + <span class="w">${wh.toFixed(1)}</span>·<span class="h">${U.fmt(h, 2)}</span> + <span class="w">${b.toFixed(1)}</span> = <b class="h">${U.fmt(nh, 2)}</b>`);
        hs.push(U.fmt(nh, Math.abs(nh) < 100 ? 2 : 0).replace(/\.00$/, '')); h = nh;
      });
      $(el, '.lr-chain').innerHTML = U.chain({ w: 900, cells: xs.map((x, i) => ({ x, h: hs[i] })), h0: 'h₀=0', showW: true, hw: 130 });
      $(el, '.lr-calc').innerHTML = rows.join('<br>');
    };
    $$(el, 'input[type=range]').forEach((r) => (r.oninput = () => { S.v[r.dataset.k] = +r.value; S.render(); }));
    $$(el, '[data-p]').forEach((b) => (b.onclick = () => { S.v = { ...P[b.dataset.p] }; S.render(); }));
    S.P = P;
  },
  step(el, k, S) {
    S.v = { ...(k === 2 ? S.P.fade : S.P.sum) };
    if (k === 0) S.v = { wx: 0.5, wh: 0.8, b: 1 };
    S.render();
  },
  says: [
    'Now give the loop knobs. W x scales the new input. W h scales the old summary. b is a constant nudge. These numbers are the weights: the things training will choose. Drag the sliders.',
    'Set W x to 1, W h to 1 and b to 0, and you get back exactly the running sum. So the running sum is one particular setting of this machine.',
    'Now turn W h down to 0.5. Each step keeps only half of the old summary, so older inputs fade. W h is literally “how much the past matters”. Hold on to that: it is the whole story of Part 4.',
  ],
});

// ───────────────────────────── 15. Squash with tanh
function lineSVG({ w, h, series, ymin, ymax, xlab = '', ylab = '', xmax, zero = true, ticksY = [] }) {
  const L = 60, R = 16, T = 16, B = 42, W = w - L - R, H = h - T - B;
  const X = (x) => L + (x / xmax) * W, Y = (y) => T + (1 - (Math.min(ymax, Math.max(ymin, y)) - ymin) / (ymax - ymin)) * H;
  let s = `<svg width="${w}" height="${h}"><rect x="${L}" y="${T}" width="${W}" height="${H}" fill="#fff" stroke="var(--rule)"/>`;
  if (zero && ymin < 0) s += `<line x1="${L}" x2="${L + W}" y1="${Y(0)}" y2="${Y(0)}" stroke="var(--rule)"/>`;
  ticksY.forEach((t) => (s += `<text x="${L - 8}" y="${Y(t) + 5}" text-anchor="end" font-size="14" fill="#8A8F9E">${t}</text>`));
  series.forEach((se) => {
    s += `<polyline fill="none" stroke="${se.color}" stroke-width="${se.width || 3}" ${se.dash ? `stroke-dasharray="${se.dash}"` : ''} points="${se.pts.map(([x, y]) => `${X(x).toFixed(1)},${Y(y).toFixed(1)}`).join(' ')}"/>`;
    if (se.label) { const [lx, ly] = se.pts[se.pts.length - 1]; s += `<text x="${X(lx) - 6}" y="${Y(ly) - 10}" text-anchor="end" font-size="16" fill="${se.color}">${se.label}</text>`; }
  });
  s += `<text x="${L + W / 2}" y="${h - 8}" text-anchor="middle" font-size="15" fill="#8A8F9E">${xlab}</text>`;
  s += `<text x="16" y="${T + H / 2}" text-anchor="middle" font-size="15" fill="#8A8F9E" transform="rotate(-90 16 ${T + H / 2})">${ylab}</text>`;
  return s + '</svg>';
}
U.lineSVG = lineSVG;
slide({
  part: 'Part 3 · Memory', title: 'Squash it: tanh',
  html: `
  <h1>Multiply over and over and <span class="h">h</span> can explode, so squash it</h1>
  <div class="row" style="margin-top:6px">
    <div class="col stack">
      <h3>Without a squash: W<sub>h</sub> = 1.2, input 1 every step</h3>
      <div class="th-lin"></div>
      <p class="small">After 30 steps <b class="h">h</b> ≈ 1,182, and still growing. Nothing downstream can work with numbers that drift without bound.</p>
    </div>
    <div class="col stack" data-step="1">
      <h3>The squash: tanh</h3>
      <div class="th-curve"></div>
      <div class="eq" style="font-size:32px"><span class="h">h<sub>t</sub></span> = <b>tanh</b>( <span class="w">W<sub>x</sub></span>·<span class="x">x<sub>t</sub></span> + <span class="w">W<sub>h</sub></span>·<span class="h">h<sub>t−1</sub></span> + <span class="w">b</span> )</div>
    </div>
    <div class="col stack" data-step="2">
      <h3>With tanh: same weights, same inputs</h3>
      <div class="th-tanh"></div>
      <p class="small">Stays between −1 and 1. This squash is the <b>activation function</b> — the non-linearity you met in weeks 2–3.</p>
    </div>
  </div>`,
  init(el) {
    let h = 0, g = 0; const lin = [[0, 0]], th = [[0, 0]];
    for (let t = 1; t <= 30; t++) { h = 1.2 * h + 1; g = Math.tanh(1.2 * g + 1); lin.push([t, h]); th.push([t, g]); }
    $(el, '.th-lin').innerHTML = lineSVG({ w: 440, h: 300, xmax: 30, ymin: 0, ymax: 1250, series: [{ pts: lin, color: 'var(--h)' }], xlab: 'step t', ylab: 'h', ticksY: [0, 500, 1000] });
    const cur = []; for (let z = -4; z <= 4.001; z += 0.1) cur.push([z + 4, Math.tanh(z)]);
    const idl = [[2.8, -1.2], [5.2, 1.2]];
    $(el, '.th-curve').innerHTML = lineSVG({ w: 440, h: 300, xmax: 8, ymin: -1.3, ymax: 1.3, series: [{ pts: idl, color: '#C9C1B0', width: 2, dash: '5 5' }, { pts: cur, color: 'var(--ink)' }], xlab: 'input z (−4 … 4)', ylab: 'tanh(z)', ticksY: [-1, 0, 1] });
    $(el, '.th-tanh').innerHTML = lineSVG({ w: 440, h: 300, xmax: 30, ymin: -1.3, ymax: 1.3, series: [{ pts: th, color: 'var(--h)' }], xlab: 'step t', ylab: 'h', ticksY: [-1, 0, 1] });
  },
  says: [
    'One problem. If W h is bigger than one, multiplying the summary over and over makes it grow without bound. After 30 steps it is over a thousand, and still climbing.',
    'The fix: squash. The function tanh takes any number and maps it into the range minus one to one. Near zero it barely changes its input — the dashed line — but big inputs get flattened to plus or minus one.',
    'Wrap the update in tanh, and the same weights now give a hidden state that stays bounded. This squash is the activation function, the non-linearity from weeks two and three.',
  ],
});

// ───────────────────────────── 16. From numbers to vectors
const WX = [[0.8, -0.2, 0.1], [0.3, 0.9, -0.5], [-0.6, 0.4, 0.7]];
const WH = [[0.5, -0.3, 0.1], [0.2, 0.6, 0.0], [-0.4, 0.1, 0.8]];
const HP = [0.2, 0.9, -0.4];
function mat(M, cls, hl = {}) {
  return `<table class="mx" style="border-spacing:3px">${M.map((r, i) => `<tr>${r.map((v, j) => `<td style="width:68px;height:48px;font-size:19px;background:${hl.col === j || hl.row === i ? cls.bg : '#fff'};color:${hl.col === j || hl.row === i ? 'var(--ink)' : 'var(--ink2)'}">${v.toFixed(1)}</td>`).join('')}</tr>`).join('')}</table>`;
}
function vec(v, color, bg, labels) {
  return `<table class="mx" style="border-spacing:3px">${v.map((x, i) => `<tr>${labels ? `<th style="height:48px;font-size:16px;color:var(--x);padding-right:4px">${labels[i]}</th>` : ''}<td style="width:68px;height:48px;font-size:19px;background:${bg};color:${color}">${typeof x === 'number' ? (Number.isInteger(x) ? x : x.toFixed(2)) : x}</td></tr>`).join('')}</table>`;
}
slide({
  part: 'Part 3 · Memory', title: 'From one number to many',
  html: `
  <h1>Real RNNs carry a <span class="h">list</span> of numbers, not one</h1>
  <p>The same formula works on lists (vectors). Each weight becomes a grid (a matrix). Toy size here: <b class="h">3</b> memory numbers, vocabulary <span class="x mono">a b c</span>. Our trained demo model: <b class="h">256</b> numbers, 65 characters.</p>
  <div class="row" style="margin-top:22px;align-items:center;gap:26px">
    <div class="center"><h3 class="w" style="text-transform:none;font-family:var(--serif);font-size:26px;letter-spacing:0">W<sub>x</sub> · <span class="x">x<sub>t</sub></span></h3>
      <div style="display:flex;align-items:center;gap:14px">${mat(WX, { bg: 'var(--w-bg)' }, { col: 1 })}<span style="font-size:30px">·</span>${vec([0, 1, 0], 'var(--x)', 'var(--x-bg)', ['a', 'b', 'c'])}<span style="font-size:30px">=</span>${vec(WX.map((r) => r[1]), 'var(--w)', 'var(--w-bg)')}</div>
      <p class="small" style="margin-top:10px">One-hot input for <b class="x">b</b> just <b>picks column b</b>:<br>each character has its own learned “push” on memory.</p></div>
    <div class="center" data-step="2" style="margin-left:30px"><h3 class="w" style="text-transform:none;font-family:var(--serif);font-size:26px;letter-spacing:0">W<sub>h</sub> · <span class="h">h<sub>t−1</sub></span></h3>
      <div style="display:flex;align-items:center;gap:14px">${mat(WH, { bg: 'var(--w-bg)' }, { row: 0 })}<span style="font-size:30px">·</span>${vec(HP, 'var(--h)', 'var(--h-bg)')}<span style="font-size:30px">=</span>${vec(WH.map((r) => r.reduce((a, w, j) => a + w * HP[j], 0)), 'var(--h)', 'var(--h-bg)')}</div>
      <p class="small mono" style="margin-top:10px">top entry: 0.5·0.2 + (−0.3)·0.9 + 0.1·(−0.4) = −0.21</p>
      <p class="small">Every new memory number is a <b>weighted blend of all</b> the old ones.</p></div>
  </div>
  <div class="eq" data-step="3" style="font-size:34px;margin-top:22px"><span class="h">h<sub>t</sub></span> = tanh( <span class="w">W<sub>x</sub></span>·<span class="x">x<sub>t</sub></span> + <span class="w">W<sub>h</sub></span>·<span class="h">h<sub>t−1</sub></span> + <span class="w">b</span> ) &nbsp; <span class="small muted" style="font-family:var(--sans)">same formula, applied to every entry at once</span></div>`,
  step(el, k) { $$(el, '.row > .center')[0].style.opacity = k >= 1 ? 1 : 0.35; },
  says: [
    'Real RNNs carry not one number but a list of them: a vector. Each weight becomes a grid of numbers: a matrix. Our toy has three memory numbers; the trained model you will see shortly has 256.',
    'Multiply W x by a one-hot input, and all it does is pick out one column: the column for the current character. So each character has its own learned push on the memory.',
    'W h times the old memory mixes it: each new number is a weighted blend of all the old ones — multiply along a row, add up.',
    'Put together, it is the same formula as before, just applied to every entry at once, then squashed with tanh.',
  ],
});

// ───────────────────────────── 17. Readout + softmax
slide({
  part: 'Part 3 · Memory', title: 'From memory to probabilities',
  html: `
  <h1>From memory to a prediction: scores, then <span class="y">softmax</span></h1>
  <div class="eq" style="margin:2px 0 14px"><span class="y">p<sub>t</sub></span> = softmax( <span class="w">W<sub>y</sub></span>·<span class="h">h<sub>t</sub></span> + <span class="w">c</span> )</div>
  <div class="row">
    <div class="col stack">
      <p><span class="w">W<sub>y</sub></span> turns the memory into <b>one score per vocabulary character</b>, called <i>logits</i>. Scores can be any number. Drag them:</p>
      <div class="card sm-sl stack" style="padding:14px 18px"></div>
    </div>
    <div class="col stack" data-step="1">
      <div class="eq" style="font-size:30px">softmax(z)<sub>i</sub> = <span style="display:inline-flex;flex-direction:column;vertical-align:middle;text-align:center"><span style="border-bottom:2px solid var(--ink);padding:0 8px">e<sup>z<sub>i</sub></sup></span><span>Σ<sub>j</sub> e<sup>z<sub>j</sub></sup></span></span></div>
      <table class="data sm-tab" style="font-size:21px"></table>
      <p class="small">1. exponentiate: everything becomes positive. &nbsp;2. divide by the total: they sum to 1. Bigger score → bigger share.</p>
    </div>
  </div>
  <div class="keyidea" data-step="2" style="margin-top:14px"><p>We’re back to a <b>row of probabilities</b>, and we sample from it exactly like the table. The difference: this row is <b>computed from a memory of everything so far</b>, not looked up from the last character alone.</p></div>`,
  init(el, S) {
    S.z = [2.0, 1.0, 0.2, -1.0];
    const labs = ['e', 'a', 'o', '␣'];
    $(el, '.sm-sl').innerHTML = labs.map((l, i) => `<div class="slider"><span class="lab mono" style="font-size:24px">${l}</span><input type="range" min="-3" max="5" step="0.1" data-i="${i}"><span class="val"></span></div>`).join('');
    S.render = () => {
      const p = U.softmax(S.z), e = S.z.map(Math.exp), tot = e.reduce((a, b) => a + b, 0);
      $$(el, '.sm-sl input').forEach((r, i) => { r.value = S.z[i]; r.nextElementSibling.textContent = S.z[i].toFixed(1); });
      $(el, '.sm-tab').innerHTML = `<tr><th>char</th><th>score z</th><th>e<sup>z</sup></th><th>÷ ${tot.toFixed(2)}</th><th style="width:34%"></th></tr>` +
        labs.map((l, i) => `<tr><td class="mono">${l}</td><td class="mono">${S.z[i].toFixed(1)}</td><td class="mono">${e[i].toFixed(2)}</td><td class="mono y">${(p[i] * 100).toFixed(1)}%</td><td><div class="track" style="height:20px;background:var(--paper2);border-radius:5px"><div style="height:100%;width:${p[i] * 100}%;background:var(--y);border-radius:5px;transition:width .3s"></div></div></td></tr>`).join('');
    };
    $$(el, '.sm-sl input').forEach((r) => (r.oninput = () => { S.z[+r.dataset.i] = +r.value; S.render(); }));
    S.render();
  },
  step(el, k, S) { S.z = [2.0, 1.0, 0.2, -1.0]; S.render(); },
  says: [
    'The memory is not a prediction yet. A third weight matrix, W y, turns it into one score per character in the vocabulary. These raw scores are called logits, and they can be any number, positive or negative.',
    'Softmax turns scores into probabilities. Exponentiate each score, which makes everything positive, then divide by the total so they sum to one. A bigger score gets a bigger share — and a score one point higher gets about 2.7 times the share.',
    'And we are back to a row of probabilities, which we sample exactly as before. The difference: this row was computed from a memory of everything so far, not looked up from the last character alone.',
  ],
});

// ───────────────────────────── 18. Unrolling
slide({
  part: 'Part 3 · Memory', title: 'Unrolling in time',
  html: `
  <h1>One cell, reused at every step: “unrolling” the loop</h1>
  <div class="row" style="align-items:center;gap:30px;margin-top:0">
    <div style="flex:none;width:250px" class="center" data-dim="1">
      <svg width="250" height="400" viewBox="0 0 250 400">
        <defs><marker id="ar2" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0L10,5L0,10z" fill="#9A9FAE"/></marker></defs>
        <rect x="65" y="160" width="120" height="76" rx="16" fill="var(--h-bg)" stroke="var(--h)" stroke-width="2"/><text x="125" y="207" text-anchor="middle" font-size="30" fill="var(--h)" font-family="Newsreader">h</text>
        <path d="M185,185 C245,185 245,110 125,110 C60,110 40,150 62,178" fill="none" stroke="var(--h)" stroke-width="3" marker-end="url(#ar2)"/>
        <text x="215" y="120" font-size="19" fill="var(--w)" font-family="Newsreader" font-style="italic">W<tspan font-size="13" dy="4">h</tspan></text>
        <circle cx="125" cy="330" r="28" fill="var(--x-bg)" stroke="var(--x)" stroke-width="2"/><text x="125" y="339" text-anchor="middle" font-size="25" fill="var(--x)" font-family="Newsreader">x</text>
        <line x1="125" y1="300" x2="125" y2="242" stroke="#9A9FAE" stroke-width="2" marker-end="url(#ar2)"/>
        <rect x="85" y="20" width="80" height="52" rx="10" fill="var(--y-bg)" stroke="var(--y)" stroke-width="2"/><text x="125" y="54" text-anchor="middle" font-size="23" fill="var(--y)" font-family="Newsreader">p</text>
        <line x1="125" y1="156" x2="125" y2="78" stroke="#9A9FAE" stroke-width="2" marker-end="url(#ar2)"/>
      </svg>
      <p class="small">rolled up</p>
    </div>
    <div class="col" data-step="1"><div class="un-chain"></div><p class="small center" style="margin-top:-6px">unrolled: reading <span class="mono x">hello</span>; top row = what it should predict next</p></div>
  </div>
  <div class="assume plural" data-step="3" style="margin-top:8px"><ul>
    <li><b>Same weights at every step</b> (weight sharing): one rule, applied at every position, so any length works.</li>
    <li>Memory has a <b>fixed size</b>, however long the text. Everything about the past must fit through the amber arrows.</li>
  </ul></div>`,
  step(el, k) {
    const cells = [...'hello'].map((c, i) => ({ x: c, h: 'h' + '₁₂₃₄₅'[i], y: 'ello␣'[i] }));
    $(el, '.un-chain').innerHTML = U.chain({ w: 1150, cells, showY: true, showW: k >= 2, h0: 'h₀' });
    $$(el, '.un-chain svg text[fill="var(--w)"]').forEach((t) => (t.style.fontWeight = k === 2 ? 700 : 400));
  },
  says: [
    'Drawn with its loop, an RNN is one small cell: input in, memory updated, prediction out, and the memory fed back in for next time.',
    'Unroll the loop through time and you see a chain, one copy of the cell per character. Reading “hello”: after h it should predict e, after e, l, and so on.',
    'Crucially, every copy uses the same three weight matrices. The model learns one rule for updating memory and applies it at every position. That is why it handles text of any length.',
    'And every copy passes forward the same fixed-size memory. Everything the model knows about the past has to squeeze through those amber arrows.',
  ],
});
})();
