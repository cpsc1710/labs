/* Reference JS implementation of the deck's vanilla char-RNN. Plain browser JS, no dependencies.
 *   h_t      = tanh(Wx[:, x_t] + Wh h_{t-1} + b)     (x_t is a char index; Wx is H x V, row-major)
 *   logits_t = Wy h_t + c                            (Wy is V x H, row-major)
 * Usage:  const m = RNNRuntime.loadCheckpoint(RNN_DATA, ckptIndex);
 *         let h = RNNRuntime.zeros(m.H);  h = RNNRuntime.step(m, h, xIdx);  const z = RNNRuntime.logits(m, h);
 */
(function (root) {
  'use strict';

  function base64ToBytes(b64) {
    if (typeof atob === 'function') {
      const s = atob(b64), n = s.length, out = new Uint8Array(n);
      for (let i = 0; i < n; i++) out[i] = s.charCodeAt(i);
      return out;
    }
    return new Uint8Array(Buffer.from(b64, 'base64'));   // node
  }

  // IEEE half -> float, done by hand so it does not depend on host endianness or Float16Array support.
  function halfToFloat(u) {
    const s = (u & 0x8000) ? -1 : 1, e = (u >> 10) & 0x1f, f = u & 0x3ff;
    if (e === 0) return s * f * 5.960464477539063e-8;            // subnormal: f * 2^-24
    if (e === 31) return f ? NaN : s * Infinity;
    return s * (1 + f / 1024) * Math.pow(2, e - 15);
  }

  // base64 of little-endian float16, row-major -> Float32Array
  function decodeFloat16(b64) {
    const b = base64ToBytes(b64), n = b.length >> 1, out = new Float32Array(n);
    for (let i = 0; i < n; i++) out[i] = halfToFloat(b[2 * i] | (b[2 * i + 1] << 8));
    return out;
  }

  // base64 of int8 -> Int8Array (used by hidden.js)
  function decodeInt8(b64) {
    const b = base64ToBytes(b64);
    return new Int8Array(b.buffer, b.byteOffset, b.length);
  }

  function loadCheckpoint(data, i) {
    const ck = data.checkpoints[i], w = ck.weights;
    return {
      H: data.H, V: data.V, vocab: data.vocab, step: ck.step,
      Wx: decodeFloat16(w.Wx.data), Wh: decodeFloat16(w.Wh.data), b: decodeFloat16(w.b.data),
      Wy: decodeFloat16(w.Wy.data), c: decodeFloat16(w.c.data),
    };
  }

  function zeros(H) { return new Float32Array(H); }

  // h_new = tanh(Wx[:, x] + Wh h + b)
  function step(m, h, x) {
    const H = m.H, V = m.V, out = new Float32Array(H);
    for (let i = 0; i < H; i++) {
      let a = m.Wx[i * V + x] + m.b[i];
      const row = i * H;
      for (let j = 0; j < H; j++) a += m.Wh[row + j] * h[j];
      out[i] = Math.tanh(a);
    }
    return out;
  }

  // logits = Wy h + c
  function logits(m, h) {
    const H = m.H, V = m.V, out = new Float32Array(V);
    for (let k = 0; k < V; k++) {
      let a = m.c[k];
      const row = k * H;
      for (let j = 0; j < H; j++) a += m.Wy[row + j] * h[j];
      out[k] = a;
    }
    return out;
  }

  // softmax(z / T), numerically stable
  function softmax(z, T) {
    T = (T === undefined) ? 1 : T;
    const n = z.length, p = new Float32Array(n);
    let mx = -Infinity;
    for (let i = 0; i < n; i++) if (z[i] > mx) mx = z[i];
    let s = 0;
    for (let i = 0; i < n; i++) { const e = Math.exp((z[i] - mx) / T); p[i] = e; s += e; }
    for (let i = 0; i < n; i++) p[i] /= s;
    return p;
  }

  // mulberry32: small seedable PRNG, returns a function giving floats in [0, 1)
  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // inverse-CDF draw: index whose cumulative probability first exceeds r = rng()
  function sample(p, rng) {
    const r = rng();
    let acc = 0;
    for (let i = 0; i < p.length; i++) { acc += p[i]; if (r < acc) return i; }
    return p.length - 1;
  }

  function encode(m, str) { return Array.from(str, ch => m.vocab.indexOf(ch)); }   // chars only in vocab

  // Feed `prompt` (string), then draw n chars at temperature T. Returns {text, h}.
  function generate(m, prompt, n, T, rng) {
    let h = zeros(m.H);
    for (const x of encode(m, prompt)) h = step(m, h, x);
    let out = '';
    for (let t = 0; t < n; t++) {
      const x = sample(softmax(logits(m, h), T), rng);
      out += m.vocab[x];
      h = step(m, h, x);
    }
    return { text: out, h: h };
  }

  const API = { decodeFloat16, decodeInt8, halfToFloat, loadCheckpoint, zeros, step, logits, softmax,
                mulberry32, sample, encode, generate };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.RNNRuntime = API;
})(typeof window !== 'undefined' ? window : globalThis);
